package com.example

import com.example.data.local.VmProfileEntity
import com.example.data.model.BootOrder
import com.example.data.model.NetworkMode
import com.example.data.model.SharedStorageMode
import com.example.data.model.VideoDriver
import com.example.data.model.VmArch
import com.example.domain.QemuCommandBuilder
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QemuCommandBuilderTest {

    @Test
    fun `builds x86_64 TCG command with SAF ISO fd and qcow2 disk`() {
        val profile = VmProfileEntity(
            id = 1L,
            name = "BlissOS",
            arch = VmArch.X86_64.name,
            cpuCores = 2,
            ramMb = 1536,
            liveMode = false,
            diskPath = "/data/user/0/com.example.droidpcvm/files/disks/bliss.qcow2",
            bootOrder = BootOrder.CD_THEN_DISK.name,
            videoDriver = VideoDriver.STD.name,
            networkMode = NetworkMode.USER_VIRTIO.name
        )

        val spec = QemuCommandBuilder.build(
            profile = profile,
            isoFd = 42,
            diskFd = null,
            extraDiskFd = null,
            sharedFatDirPath = null,
            qmpSocketPath = "/tmp/vm_1.qmp",
            biosDirPath = "/tmp/bios",
            vncDisplayNumber = 1,
            kvmAvailable = false
        )

        val cmd = spec.toDisplayCommand()
        assertTrue(cmd.contains("-accel tcg,thread=multi,tb-size=128"))
        assertTrue(cmd.contains("-cdrom /proc/self/fd/42"))
        assertTrue(cmd.contains("format=qcow2,if=virtio"))
        assertTrue(cmd.contains("-netdev user,id=net0"))
        assertTrue(cmd.contains("-vnc 127.0.0.1:1"))
        assertTrue(spec.ownedFds.contains(42))
    }

    @Test
    fun `live mode omits primary disk drive`() {
        val profile = VmProfileEntity(
            id = 2L,
            name = "LiveAndroid",
            liveMode = true,
            diskPath = "/should/not/be/used.qcow2",
            sharedStorageMode = SharedStorageMode.NONE.name
        )

        val spec = QemuCommandBuilder.build(
            profile = profile,
            isoFd = 55,
            diskFd = 99,
            extraDiskFd = null,
            sharedFatDirPath = null,
            qmpSocketPath = "/tmp/vm_2.qmp",
            biosDirPath = null
        )

        val cmd = spec.toDisplayCommand()
        assertTrue(cmd.contains("-cdrom /proc/self/fd/55"))
        assertFalse(cmd.contains("should/not/be/used"))
        assertFalse(spec.ownedFds.contains(99))
    }

    @Test
    fun `enables kvm only on aarch64 when device supports it`() {
        val profile = VmProfileEntity(
            id = 3L,
            name = "Arm64Guest",
            arch = VmArch.AARCH64.name,
            useKvmIfAvailable = true
        )

        val spec = QemuCommandBuilder.build(
            profile = profile,
            isoFd = null,
            diskFd = null,
            extraDiskFd = null,
            sharedFatDirPath = null,
            qmpSocketPath = "/tmp/vm_3.qmp",
            biosDirPath = null,
            kvmAvailable = true
        )

        val cmd = spec.toDisplayCommand()
        assertTrue(cmd.contains("-machine virt,accel=kvm"))
        assertTrue(cmd.contains("-cpu host"))
    }
}
