package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.DiskFormat
import com.example.domain.DiskImageManager
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DiskImageManagerTest {

    @Test
    fun `creates valid qcow2 v3 header`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = DiskImageManager(context)
        val result = manager.createDisk("test_disk_${System.nanoTime()}", 4, DiskFormat.QCOW2)

        try {
            assertTrue(result.file.exists())
            val headerBytes = ByteArray(104)
            RandomAccessFile(result.file, "r").use { raf ->
                raf.readFully(headerBytes)
            }
            val bb = ByteBuffer.wrap(headerBytes).order(ByteOrder.BIG_ENDIAN)
            assertEquals(0x514649fb, bb.int) // magic QFI\xfb
            assertEquals(3, bb.int) // version 3
            bb.long // backing_file_offset
            bb.int // backing_file_size
            assertEquals(16, bb.int) // cluster_bits (64 KiB)
            assertEquals(4L * 1024L * 1024L * 1024L, bb.long) // virtual size
        } finally {
            manager.deleteDisk(result.file)
        }
    }

    @Test
    fun `creates sparse raw img file with requested length`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = DiskImageManager(context)
        val result = manager.createDisk("test_raw_${System.nanoTime()}", 2, DiskFormat.RAW)

        try {
            assertTrue(result.file.exists())
            assertEquals(2L * 1024L * 1024L * 1024L, result.file.length())
        } finally {
            manager.deleteDisk(result.file)
        }
    }
}
