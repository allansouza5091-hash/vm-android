#include "qmp_socket.h"

#include <cerrno>
#include <cstring>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/un.h>
#include <unistd.h>

namespace droidpc {

namespace {

bool readLineWithTimeout(int fd, std::string& outLine) {
    outLine.clear();
    char ch = 0;
    while (true) {
        ssize_t n = recv(fd, &ch, 1, 0);
        if (n <= 0) {
            return !outLine.empty();
        }
        if (ch == '\n') {
            return true;
        }
        outLine.push_back(ch);
        if (outLine.size() > 65536) {
            return true;
        }
    }
}

}  // namespace

bool sendQmpCommand(
    const std::string& socketPath,
    const std::string& jsonCommand,
    std::string& responseOut,
    std::string& errorOut
) {
    if (socketPath.empty()) {
        errorOut = "Caminho do socket QMP vazio.";
        return false;
    }

    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) {
        errorOut = std::string("Falha ao criar socket QMP: ") + strerror(errno);
        return false;
    }

    struct timeval tv{};
    tv.tv_sec = 3;
    tv.tv_usec = 0;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));

    struct sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    if (socketPath.size() >= sizeof(addr.sun_path)) {
        close(fd);
        errorOut = "Caminho do socket QMP excede limite sun_path.";
        return false;
    }
    std::strncpy(addr.sun_path, socketPath.c_str(), sizeof(addr.sun_path) - 1);

    if (connect(fd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0) {
        errorOut = std::string("Falha ao conectar ao QMP: ") + strerror(errno);
        close(fd);
        return false;
    }

    // Lê banner inicial {"QMP": ...}
    std::string greeting;
    if (!readLineWithTimeout(fd, greeting)) {
        errorOut = "Timeout aguardando greeting QMP.";
        close(fd);
        return false;
    }

    // Negocia capacidades QMP
    const std::string capsCmd = "{\"execute\":\"qmp_capabilities\"}\r\n";
    if (send(fd, capsCmd.data(), capsCmd.size(), 0) < 0) {
        errorOut = std::string("Erro enviando qmp_capabilities: ") + strerror(errno);
        close(fd);
        return false;
    }
    std::string capsResp;
    readLineWithTimeout(fd, capsResp);

    // Envia comando desejado
    std::string payload = jsonCommand;
    if (payload.empty() || payload.back() != '\n') {
        payload.append("\r\n");
    }
    if (send(fd, payload.data(), payload.size(), 0) < 0) {
        errorOut = std::string("Erro enviando comando QMP: ") + strerror(errno);
        close(fd);
        return false;
    }

    // Lê resposta (ignorando eventos assíncronos eventuais)
    for (int attempt = 0; attempt < 5; ++attempt) {
        if (!readLineWithTimeout(fd, responseOut)) {
            errorOut = "Sem resposta do QMP.";
            close(fd);
            return false;
        }
        if (responseOut.find("\"event\"") == std::string::npos) {
            break;
        }
    }

    close(fd);
    return true;
}

}  // namespace droidpc
