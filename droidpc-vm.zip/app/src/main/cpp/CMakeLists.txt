cmake_minimum_required(VERSION 3.22.1)
project(qemu_bridge LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

include_directories(${CMAKE_CURRENT_SOURCE_DIR}/include)

add_library(
    qemu_bridge
    SHARED
    qemu_jni.cpp
    qmp_socket.cpp
    audio_bridge.cpp
)

find_library(log-lib log)
find_library(android-lib android)
find_library(aaudio-lib aaudio)

target_link_libraries(
    qemu_bridge
    ${log-lib}
    ${android-lib}
    ${aaudio-lib}
)
