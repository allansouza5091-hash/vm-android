#include <aaudio/AAudio.h>
#include <android/log.h>
#include <atomic>
#include <cstring>
#include <jni.h>
#include <mutex>
#include <vector>

#define LOG_TAG "DroidPC_Audio"
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

std::mutex gAudioMutex;
AAudioStream* gAudioStream = nullptr;
std::atomic<bool> gAudioActive{false};
constexpr int32_t kSampleRate = 44100;
constexpr int32_t kChannelCount = 2;

}  // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_example_nativebridge_QemuNativeBridge_nativeInitAudio(
    JNIEnv* /*env*/,
    jobject /*thiz*/,
    jint sampleRate,
    jint channels
) {
    std::lock_guard<std::mutex> lock(gAudioMutex);
    if (gAudioStream != nullptr) {
        AAudioStream_requestStop(gAudioStream);
        AAudioStream_close(gAudioStream);
        gAudioStream = nullptr;
    }

    AAudioStreamBuilder* builder = nullptr;
    aaudio_result_t result = AAudio_createStreamBuilder(&builder);
    if (result != AAUDIO_OK || builder == nullptr) {
        ALOGE("AAudio_createStreamBuilder falhou: %s", AAudio_convertResultToText(result));
        return JNI_FALSE;
    }

    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setSampleRate(builder, sampleRate > 0 ? sampleRate : kSampleRate);
    AAudioStreamBuilder_setChannelCount(builder, channels > 0 ? channels : kChannelCount);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_I16);
    AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);

    result = AAudioStreamBuilder_openStream(builder, &gAudioStream);
    AAudioStreamBuilder_delete(builder);

    if (result != AAUDIO_OK || gAudioStream == nullptr) {
        ALOGE("AAudioStreamBuilder_openStream falhou: %s", AAudio_convertResultToText(result));
        gAudioStream = nullptr;
        return JNI_FALSE;
    }

    result = AAudioStream_requestStart(gAudioStream);
    if (result != AAUDIO_OK) {
        ALOGE("AAudioStream_requestStart falhou: %s", AAudio_convertResultToText(result));
        AAudioStream_close(gAudioStream);
        gAudioStream = nullptr;
        return JNI_FALSE;
    }

    gAudioActive.store(true);
    ALOGI("Stream AAudio iniciado (%d Hz, %d canais)", sampleRate, channels);
    return JNI_TRUE;
}

JNIEXPORT jint JNICALL
Java_com_example_nativebridge_QemuNativeBridge_nativeWriteAudioPcm(
    JNIEnv* env,
    jobject /*thiz*/,
    jbyteArray pcmData,
    jint lengthBytes
) {
    if (!gAudioActive.load() || pcmData == nullptr || lengthBytes <= 0) {
        return 0;
    }

    std::lock_guard<std::mutex> lock(gAudioMutex);
    if (gAudioStream == nullptr) {
        return -1;
    }

    jbyte* raw = env->GetByteArrayElements(pcmData, nullptr);
    if (raw == nullptr) {
        return -1;
    }

    const int32_t channels = AAudioStream_getChannelCount(gAudioStream);
    const int32_t bytesPerFrame = channels * static_cast<int32_t>(sizeof(int16_t));
    const int32_t numFrames = lengthBytes / bytesPerFrame;

    aaudio_result_t written = 0;
    if (numFrames > 0) {
        written = AAudioStream_write(gAudioStream, raw, numFrames, 50000000L);
    }

    env->ReleaseByteArrayElements(pcmData, raw, JNI_ABORT);
    return written >= 0 ? written * bytesPerFrame : -1;
}

JNIEXPORT void JNICALL
Java_com_example_nativebridge_QemuNativeBridge_nativeCloseAudio(
    JNIEnv* /*env*/,
    jobject /*thiz*/
) {
    std::lock_guard<std::mutex> lock(gAudioMutex);
    gAudioActive.store(false);
    if (gAudioStream != nullptr) {
        AAudioStream_requestStop(gAudioStream);
        AAudioStream_close(gAudioStream);
        gAudioStream = nullptr;
        ALOGI("Stream AAudio encerrado");
    }
}

}  // extern "C"
