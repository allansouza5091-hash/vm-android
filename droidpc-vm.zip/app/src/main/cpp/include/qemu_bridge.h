#pragma once

#include <jni.h>
#include <string>
#include <vector>

namespace droidpc {

typedef int (*QemuMainFn)(int argc, char** argv);

struct NativeVmConfig {
    std::string libraryName;
    std::vector<std::string> args;
    std::vector<int> ownedFds;
};

}  // namespace droidpc
