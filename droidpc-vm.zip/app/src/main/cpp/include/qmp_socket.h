#pragma once

#include <string>

namespace droidpc {

bool sendQmpCommand(
    const std::string& socketPath,
    const std::string& jsonCommand,
    std::string& responseOut,
    std::string& errorOut
);

}  // namespace droidpc
