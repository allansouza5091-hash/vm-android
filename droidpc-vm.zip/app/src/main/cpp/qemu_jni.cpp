#include "qemu_bridge.h"
#include "qmp_socket.h"

#include <android/log.h>
#include <atomic>
#include <cerrno>
#include <cstring>
#include <dlfcn.h>
#include <fcntl.h>
#include <jni.h>
#include <mutex>
#include <string>
#include <thread>
#include <unistd.h>
#include <vector>

#define LOG_TAG "DroidPC_JNI"
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

JavaVM* gJvm = nullptr;
std::mutex gStateMutex;
std::atomic<bool> gVmRunning{false};
jobject gCallbackObj = nullptr;
jmethodID gOnLogMethod = nullptr;
jmethodID gOnExitMethod = nullptr;

int gLogPipe[2] = {-1, -1};
std::thread gLogThread;
std::thread gQemuThread;
std::atomic<bool> gLoggingActive{false};
std::vector<int> gOwnedFds;

void emitLogToKotlin(const std::string& line) {
    if (gJvm == nullptr || gCallbackObj == nullptr || gOnLogMethod == nullptr) {
        return;
    }
    JNIEnv* env = nullptr;
    bool attached = false;
    if (gJvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (gJvm->AttachCurrentThread(&env, nullptr) != JNI_OK) {
            return;
        }
        attached = true;
    }
    jstring jLine = env->NewStringUTF(line.c_str());
    if (jLine != nullptr) {
        env->CallVoidMethod(gCallbackObj, gOnLogMethod, jLine);
        env->DeleteLocalRef(jLine);
    }
    if (attached) {
        gJvm->DetachCurrentThread();
    }
}

void emitExitToKotlin(int exitCode, const std::string& message) {
    if (gJvm == nullptr || gCallbackObj == nullptr || gOnExitMethod == nullptr) {
        return;
    }
    JNIEnv* env = nullptr;
    bool attached = false;
    if (gJvm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        if (gJvm->AttachCurrentThread(&env, nullptr) != JNI_OK) {
            return;
        }
        attached = true;
    }
    jstring jMsg = env->NewStringUTF(message.c_str());
    env->CallVoidMethod(gCallbackObj, gOnExitMethod, static_cast<jint>(exitCode), jMsg);
    if (jMsg != nullptr) {
        env->DeleteLocalRef(jMsg);
    }
    if (attached) {
        gJvm->DetachCurrentThread();
    }
}

void startStdioRedirect() {
    if (pipe2(gLogPipe, O_CLOEXEC) != 0) {
        ALOGE("Falha ao criar pipe de logs: %s", strerror(errno));
        return;
    }
    dup2(gLogPipe[1], STDOUT_FILENO);
    dup2(gLogPipe[1], STDERR_FILENO);
    setvbuf(stdout, nullptr, _IOLBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);

    gLoggingActive.store(true);
    gLogThread = std::thread([]() {
        char buffer[1024];
        std::string pending;
        while (gLoggingActive.load()) {
            ssize_t count = read(gLogPipe[0], buffer, sizeof(buffer) - 1);
            if (count <= 0) {
                break;
            }
            buffer[count] = '\0';
            pending.append(buffer, static_cast<size_t>(count));
            size_t pos = 0;
            while ((pos = pending.find('\n')) != std::string::npos) {
                std::string line = pending.substr(0, pos);
                pending.erase(0, pos + 1);
                if (!line.empty()) {
                    ALOGI("[QEMU] %s", line.c_str());
                    emitLogToKotlin(line);
                }
            }
        }
        if (!pending.empty()) {
            emitLogToKotlin(pending);
        }
    });
}

void stopStdioRedirectAndCloseFds() {
    gLoggingActive.store(false);
    if (gLogPipe[1] >= 0) {
        close(gLogPipe[1]);
        gLogPipe[1] = -1;
    }
    if (gLogPipe[0] >= 0) {
        close(gLogPipe[0]);
        gLogPipe[0] = -1;
    }
    if (gLogThread.joinable()) {
        gLogThread.join();
    }
    for (int fd : gOwnedFds) {
        if (fd >= 0) {
            close(fd);
        }
    }
    gOwnedFds.clear();
}

}  // namespace

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* /*reserved*/) {
    gJvm = vm;
    return JNI_VERSION_1_6;
}

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_example_nativebridge_QemuNativeBridge_nativeIsEngineAvailable(
    JNIEnv* env,
    jobject /*thiz*/,
    jstring libraryName
) {
    const char* rawLib = env->GetStringUTFChars(libraryName, nullptr);
    if (rawLib == nullptr) {
        return JNI_FALSE;
    }
    void* handle = dlopen(rawLib, RTLD_NOW | RTLD_LOCAL);
    if (handle == nullptr) {
        ALOGI("Biblioteca %s indisponível: %s", rawLib, dlerror());
        env->ReleaseStringUTFChars(libraryName, rawLib);
        return JNI_FALSE;
    }
    void* sym = dlsym(handle, "qemu_main");
    dlclose(handle);
    env->ReleaseStringUTFChars(libraryName, rawLib);
    return sym != nullptr ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_example_nativebridge_QemuNativeBridge_nativeStartVm(
    JNIEnv* env,
    jobject thiz,
    jstring libraryName,
    jobjectArray argsArray,
    jintArray ownedFdsArray
) {
    std::lock_guard<std::mutex> lock(gStateMutex);
    if (gVmRunning.load()) {
        ALOGE("Uma VM já está em execução neste processo.");
        return JNI_FALSE;
    }

    if (gQemuThread.joinable()) {
        gQemuThread.join();
    }

    const char* rawLib = env->GetStringUTFChars(libraryName, nullptr);
    std::string libNameStr = rawLib != nullptr ? rawLib : "libqemu-system-x86_64.so";
    if (rawLib != nullptr) {
        env->ReleaseStringUTFChars(libraryName, rawLib);
    }

    std::vector<std::string> args;
    const jsize argCount = env->GetArrayLength(argsArray);
    args.reserve(static_cast<size_t>(argCount));
    for (jsize i = 0; i < argCount; ++i) {
        auto jStr = static_cast<jstring>(env->GetObjectArrayElement(argsArray, i));
        const char* utf = env->GetStringUTFChars(jStr, nullptr);
        args.emplace_back(utf != nullptr ? utf : "");
        if (utf != nullptr) {
            env->ReleaseStringUTFChars(jStr, utf);
        }
        env->DeleteLocalRef(jStr);
    }

    gOwnedFds.clear();
    if (ownedFdsArray != nullptr) {
        const jsize fdCount = env->GetArrayLength(ownedFdsArray);
        jint* fdElems = env->GetIntArrayElements(ownedFdsArray, nullptr);
        if (fdElems != nullptr) {
            for (jsize i = 0; i < fdCount; ++i) {
                gOwnedFds.push_back(fdElems[i]);
            }
            env->ReleaseIntArrayElements(ownedFdsArray, fdElems, JNI_ABORT);
        }
    }

    if (gCallbackObj != nullptr) {
        env->DeleteGlobalRef(gCallbackObj);
        gCallbackObj = nullptr;
    }
    gCallbackObj = env->NewGlobalRef(thiz);
    jclass cls = env->GetObjectClass(thiz);
    gOnLogMethod = env->GetMethodID(cls, "onNativeLog", "(Ljava/lang/String;)V");
    gOnExitMethod = env->GetMethodID(cls, "onNativeVmExit", "(ILjava/lang/String;)V");
    env->DeleteLocalRef(cls);

    gVmRunning.store(true);
    startStdioRedirect();

    gQemuThread = std::thread([libNameStr, args]() mutable {
        void* handle = dlopen(libNameStr.c_str(), RTLD_NOW | RTLD_GLOBAL);
        if (handle == nullptr) {
            std::string err = std::string("Falha ao carregar ") + libNameStr + ": " + dlerror();
            ALOGE("%s", err.c_str());
            emitLogToKotlin(err);
            gVmRunning.store(false);
            stopStdioRedirectAndCloseFds();
            emitExitToKotlin(-1, err);
            return;
        }

        auto qemuMain = reinterpret_cast<droidpc::QemuMainFn>(dlsym(handle, "qemu_main"));
        if (qemuMain == nullptr) {
            std::string err = "Símbolo qemu_main não encontrado em " + libNameStr;
            ALOGE("%s", err.c_str());
            emitLogToKotlin(err);
            dlclose(handle);
            gVmRunning.store(false);
            stopStdioRedirectAndCloseFds();
            emitExitToKotlin(-2, err);
            return;
        }

        std::vector<char*> argvPtrs;
        argvPtrs.reserve(args.size() + 1);
        for (auto& arg : args) {
            argvPtrs.push_back(const_cast<char*>(arg.c_str()));
        }
        argvPtrs.push_back(nullptr);

        emitLogToKotlin("Iniciando QEMU nativo (" + libNameStr + ")...");
        const int argc = static_cast<int>(args.size());
        const int exitCode = qemuMain(argc, argvPtrs.data());

        dlclose(handle);
        gVmRunning.store(false);
        stopStdioRedirectAndCloseFds();
        emitExitToKotlin(exitCode, exitCode == 0 ? "VM encerrada normalmente." : "QEMU encerrou com código de erro.");
    });

    return JNI_TRUE;
}

JNIEXPORT jstring JNICALL
Java_com_example_nativebridge_QemuNativeBridge_nativeSendQmpCommand(
    JNIEnv* env,
    jobject /*thiz*/,
    jstring socketPath,
    jstring jsonCommand
) {
    const char* rawSocket = env->GetStringUTFChars(socketPath, nullptr);
    const char* rawCmd = env->GetStringUTFChars(jsonCommand, nullptr);
    std::string sockStr = rawSocket != nullptr ? rawSocket : "";
    std::string cmdStr = rawCmd != nullptr ? rawCmd : "";
    if (rawSocket != nullptr) env->ReleaseStringUTFChars(socketPath, rawSocket);
    if (rawCmd != nullptr) env->ReleaseStringUTFChars(jsonCommand, rawCmd);

    std::string response;
    std::string error;
    bool ok = droidpc::sendQmpCommand(sockStr, cmdStr, response, error);
    std::string finalResult = ok ? ("OK:" + response) : ("ERR:" + error);
    return env->NewStringUTF(finalResult.c_str());
}

JNIEXPORT jboolean JNICALL
Java_com_example_nativebridge_QemuNativeBridge_nativeIsVmRunning(
    JNIEnv* /*env*/,
    jobject /*thiz*/
) {
    return gVmRunning.load() ? JNI_TRUE : JNI_FALSE;
}

}  // extern "C"
