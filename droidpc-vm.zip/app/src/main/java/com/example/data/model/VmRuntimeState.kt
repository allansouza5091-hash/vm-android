package com.example.data.model

enum class VmRunStatus {
    STOPPED,
    STARTING,
    RUNNING,
    PAUSED,
    ERROR
}

data class TelemetrySnapshot(
    val processCpuPercent: Int = 0,
    val deviceFreeRamMb: Long = 0,
    val deviceTotalRamMb: Long = 0,
    val batteryPercent: Int = 100,
    val batteryCharging: Boolean = false,
    val batteryTempCelsius: Float = 0f,
    val thermalStatusLabel: String = "Normal",
    val isThermalThrottling: Boolean = false,
    val isLowBatteryWarning: Boolean = false
)

data class VmRuntimeState(
    val activeVmId: Long? = null,
    val activeVmName: String = "",
    val status: VmRunStatus = VmRunStatus.STOPPED,
    val statusMessage: String = "Pronto",
    val vncPort: Int = 5901,
    val qmpSocketPath: String = "",
    val isAudioEnabled: Boolean = true,
    val lastCommandLine: String = "",
    val logs: List<String> = emptyList(),
    val telemetry: TelemetrySnapshot = TelemetrySnapshot(),
    val nativeEngineMissing: Boolean = false
)

data class DeviceCapabilities(
    val totalRamMb: Long,
    val availableRamMb: Long,
    val cpuCores: Int,
    val primaryAbi: String,
    val kvmAvailable: Boolean,
    val x86EngineBundled: Boolean,
    val aarch64EngineBundled: Boolean
)
