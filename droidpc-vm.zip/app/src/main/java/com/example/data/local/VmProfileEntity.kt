package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.BootOrder
import com.example.data.model.DiskFormat
import com.example.data.model.NetworkMode
import com.example.data.model.SharedStorageMode
import com.example.data.model.VideoDriver
import com.example.data.model.VmArch

@Entity(tableName = "vm_profiles")
data class VmProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val arch: String = VmArch.X86_64.name,
    val useKvmIfAvailable: Boolean = false,
    val cpuCores: Int = 2,
    val ramMb: Int = 1536,
    val isoUri: String? = null,
    val isoDisplayName: String? = null,
    val isoSizeBytes: Long = 0L,
    val liveMode: Boolean = false,
    val diskPath: String? = null,
    val diskUri: String? = null,
    val diskDisplayName: String? = null,
    val diskFormat: String = DiskFormat.QCOW2.name,
    val diskSizeGb: Int = 8,
    val bootOrder: String = BootOrder.CD_THEN_DISK.name,
    val videoDriver: String = VideoDriver.STD.name,
    val networkMode: String = NetworkMode.USER_VIRTIO.name,
    val enableAudio: Boolean = true,
    val sharedStorageMode: String = SharedStorageMode.NONE.name,
    val sharedFolderUri: String? = null,
    val sharedFolderName: String? = null,
    val extraDiskPath: String? = null,
    val extraDiskUri: String? = null,
    val kernelPath: String? = null,
    val initrdPath: String? = null,
    val kernelOptions: String = "nomodeset DPI=160 vga=791",
    val extraQemuArgs: String = "",
    val lastSnapshotName: String = "quick_save",
    val updatedAt: Long = System.currentTimeMillis()
)
