package com.example.data.repository

import com.example.data.local.VmProfileDao
import com.example.data.local.VmProfileEntity
import java.io.File
import kotlinx.coroutines.flow.Flow

class VmRepository(private val dao: VmProfileDao) {
    val profiles: Flow<List<VmProfileEntity>> = dao.observeAll()

    suspend fun getById(id: Long): VmProfileEntity? = dao.getById(id)

    suspend fun save(profile: VmProfileEntity): Long {
        val stamped = profile.copy(updatedAt = System.currentTimeMillis())
        return if (stamped.id == 0L) {
            dao.insert(stamped)
        } else {
            dao.update(stamped)
            stamped.id
        }
    }

    suspend fun duplicate(profile: VmProfileEntity): Long {
        val copy = profile.copy(
            id = 0L,
            name = "${profile.name} (Cópia)",
            // Evita duas VMs escreverem simultaneamente no mesmo disco privado
            diskPath = null,
            diskUri = null,
            diskDisplayName = null,
            liveMode = true,
            updatedAt = System.currentTimeMillis()
        )
        return dao.insert(copy)
    }

    suspend fun delete(profile: VmProfileEntity, deletePrivateDisk: Boolean) {
        if (deletePrivateDisk) {
            profile.diskPath?.let { path ->
                runCatching { File(path).takeIf { it.exists() }?.delete() }
            }
        }
        dao.deleteById(profile.id)
    }
}
