package com.example.data.model

enum class VmArch(
    val displayName: String,
    val libraryName: String,
    val qemuMachine: String,
    val defaultCpu: String
) {
    X86_64(
        displayName = "x86_64 (TCG Emulação)",
        libraryName = "libqemu-system-x86_64.so",
        qemuMachine = "q35",
        defaultCpu = "qemu64,+ssse3,+sse4.1,+sse4.2"
    ),
    AARCH64(
        displayName = "ARM64 (KVM / TCG)",
        libraryName = "libqemu-system-aarch64.so",
        qemuMachine = "virt",
        defaultCpu = "cortex-a57"
    )
}

enum class VideoDriver(val displayName: String, val qemuFlagValue: String) {
    STD("VGA Padrão (Bochs/std - mais compatível)", "std"),
    VIRTIO("VirtIO VGA (melhor resolução 2D)", "virtio"),
    VMWARE("VMware SVGA-II", "vmware"),
    CIRRUS("Cirrus Logic (legado)", "cirrus")
}

enum class BootOrder(val displayName: String, val qemuOrder: String) {
    CD_THEN_DISK("CD-ROM (ISO) -> Disco", "dc"),
    DISK_THEN_CD("Disco -> CD-ROM (ISO)", "cd"),
    CD_ONLY("Somente CD-ROM (Live)", "d")
}

enum class DiskFormat(val extension: String, val qemuFormat: String) {
    QCOW2("qcow2", "qcow2"),
    RAW("img", "raw")
}

enum class NetworkMode(val displayName: String) {
    USER_VIRTIO("NAT / User (virtio-net)"),
    USER_E1000("NAT / User (Intel e1000 - compatível)"),
    DISABLED("Desativada")
}

enum class SharedStorageMode(val displayName: String) {
    NONE("Nenhum"),
    SHARED_FOLDER_VVFAT("Pasta compartilhada (FAT virtual)"),
    EXTRA_DISK("Disco virtual extra")
}
