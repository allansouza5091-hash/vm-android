package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VmProfileDao {
    @Query("SELECT * FROM vm_profiles ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<VmProfileEntity>>

    @Query("SELECT * FROM vm_profiles WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): VmProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(profile: VmProfileEntity): Long

    @Update
    suspend fun update(profile: VmProfileEntity)

    @Query("DELETE FROM vm_profiles WHERE id = :id")
    suspend fun deleteById(id: Long)
}
