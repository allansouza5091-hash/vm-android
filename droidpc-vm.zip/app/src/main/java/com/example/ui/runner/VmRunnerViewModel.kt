package com.example.ui.runner

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.data.model.VmRuntimeState
import com.example.service.VmServiceController
import com.example.vnc.VncFrameState
import kotlinx.coroutines.flow.StateFlow

class VmRunnerViewModel(application: Application) : AndroidViewModel(application) {
    val runtimeState: StateFlow<VmRuntimeState> = VmServiceController.runtimeState
    val vncFrameState: StateFlow<VncFrameState> = VmServiceController.vncFrameState

    fun togglePause() = VmServiceController.pauseOrResume(getApplication())
    fun resetVm() = VmServiceController.resetVm(getApplication())
    fun powerdownVm() = VmServiceController.powerdownVm(getApplication())
    fun forceStopVm() = VmServiceController.forceStopVm(getApplication())
    fun saveState(tag: String = "quick_save") = VmServiceController.saveSnapshot(tag)
    fun loadState(tag: String = "quick_save") = VmServiceController.loadSnapshot(tag)
    fun sendCtrlAltDel() = VmServiceController.sendCtrlAltDel()
    fun sendPointer(x: Int, y: Int, buttonMask: Int) = VmServiceController.sendPointer(x, y, buttonMask)
    fun sendKeyEvent(down: Boolean, keySym: Int) = VmServiceController.sendKeyEvent(down, keySym)
    fun sendKeyTap(keySym: Int) = VmServiceController.sendKeyTap(keySym)
}
