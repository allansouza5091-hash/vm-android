package com.example.ui.config

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.VmApplication
import com.example.data.local.VmProfileEntity
import com.example.data.model.BootOrder
import com.example.data.model.DeviceCapabilities
import com.example.data.model.DiskFormat
import com.example.data.model.NetworkMode
import com.example.data.model.SharedStorageMode
import com.example.data.model.VideoDriver
import com.example.data.model.VmArch
import com.example.domain.DeviceCapabilityChecker
import com.example.domain.DiskImageManager
import com.example.domain.QemuCommandBuilder
import com.example.domain.SafFileManager
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class VmConfigUiState(
    val id: Long = 0L,
    val name: String = "Android-x86 PC",
    val arch: VmArch = VmArch.X86_64,
    val useKvmIfAvailable: Boolean = false,
    val cpuCores: Int = 2,
    val ramMb: Int = 1536,
    val maxSafeRamMb: Int = 2048,
    val isoUri: String? = null,
    val isoDisplayName: String? = null,
    val isoSizeBytes: Long = 0L,
    val liveMode: Boolean = false,
    val diskPath: String? = null,
    val diskUri: String? = null,
    val diskDisplayName: String? = null,
    val diskFormat: DiskFormat = DiskFormat.QCOW2,
    val diskSizeGb: Int = 8,
    val bootOrder: BootOrder = BootOrder.CD_THEN_DISK,
    val videoDriver: VideoDriver = VideoDriver.STD,
    val networkMode: NetworkMode = NetworkMode.USER_VIRTIO,
    val enableAudio: Boolean = true,
    val sharedStorageMode: SharedStorageMode = SharedStorageMode.NONE,
    val sharedFolderUri: String? = null,
    val sharedFolderName: String? = null,
    val extraDiskUri: String? = null,
    val extraDiskName: String? = null,
    val kernelOptions: String = "nomodeset DPI=160 vga=791",
    val extraQemuArgs: String = "",
    val availablePrivateDisks: List<File> = emptyList(),
    val freeStorageGb: Double = 0.0,
    val capabilities: DeviceCapabilities? = null,
    val feedbackMessage: String? = null,
    val isSaved: Boolean = false
)

class VmConfigViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VmApplication
    private val repository = app.repository
    private val safManager = SafFileManager(application)
    private val diskManager = DiskImageManager(application)
    private val capabilityChecker = DeviceCapabilityChecker(application)

    private val _uiState = MutableStateFlow(VmConfigUiState())
    val uiState: StateFlow<VmConfigUiState> = _uiState.asStateFlow()

    init {
        loadDeviceContext()
    }

    private fun loadDeviceContext() {
        val caps = capabilityChecker.inspect()
        val safeRam = capabilityChecker.recommendedMaxVmRamMb(caps.availableRamMb, caps.totalRamMb)
        _uiState.update { state ->
            state.copy(
                capabilities = caps,
                maxSafeRamMb = safeRam,
                ramMb = state.ramMb.coerceAtMost(safeRam),
                availablePrivateDisks = diskManager.listPrivateDisks(),
                freeStorageGb = diskManager.getAvailableStorageGb()
            )
        }
    }

    fun loadProfile(vmId: Long?) {
        if (vmId == null || vmId <= 0L) return
        viewModelScope.launch {
            val entity = repository.getById(vmId) ?: return@launch
            _uiState.update { current ->
                current.copy(
                    id = entity.id,
                    name = entity.name,
                    arch = runCatching { VmArch.valueOf(entity.arch) }.getOrDefault(VmArch.X86_64),
                    useKvmIfAvailable = entity.useKvmIfAvailable,
                    cpuCores = entity.cpuCores,
                    ramMb = entity.ramMb.coerceAtMost(current.maxSafeRamMb),
                    isoUri = entity.isoUri,
                    isoDisplayName = entity.isoDisplayName,
                    isoSizeBytes = entity.isoSizeBytes,
                    liveMode = entity.liveMode,
                    diskPath = entity.diskPath,
                    diskUri = entity.diskUri,
                    diskDisplayName = entity.diskDisplayName,
                    diskFormat = runCatching { DiskFormat.valueOf(entity.diskFormat) }.getOrDefault(DiskFormat.QCOW2),
                    diskSizeGb = entity.diskSizeGb,
                    bootOrder = runCatching { BootOrder.valueOf(entity.bootOrder) }.getOrDefault(BootOrder.CD_THEN_DISK),
                    videoDriver = runCatching { VideoDriver.valueOf(entity.videoDriver) }.getOrDefault(VideoDriver.STD),
                    networkMode = runCatching { NetworkMode.valueOf(entity.networkMode) }.getOrDefault(NetworkMode.USER_VIRTIO),
                    enableAudio = entity.enableAudio,
                    sharedStorageMode = runCatching { SharedStorageMode.valueOf(entity.sharedStorageMode) }
                        .getOrDefault(SharedStorageMode.NONE),
                    sharedFolderUri = entity.sharedFolderUri,
                    sharedFolderName = entity.sharedFolderName,
                    extraDiskUri = entity.extraDiskUri,
                    extraDiskName = entity.extraDiskPath,
                    kernelOptions = entity.kernelOptions,
                    extraQemuArgs = entity.extraQemuArgs
                )
            }
        }
    }

    fun updateName(value: String) = _uiState.update { it.copy(name = value) }
    fun updateArch(value: VmArch) = _uiState.update { it.copy(arch = value) }
    fun updateUseKvm(value: Boolean) = _uiState.update { it.copy(useKvmIfAvailable = value) }
    fun updateCpuCores(value: Int) = _uiState.update { it.copy(cpuCores = value.coerceIn(1, 8)) }
    fun updateRamMb(value: Int) = _uiState.update { it.copy(ramMb = value.coerceIn(256, it.maxSafeRamMb)) }
    fun updateLiveMode(value: Boolean) = _uiState.update { it.copy(liveMode = value) }
    fun updateBootOrder(value: BootOrder) = _uiState.update { it.copy(bootOrder = value) }
    fun updateVideoDriver(value: VideoDriver) = _uiState.update { it.copy(videoDriver = value) }
    fun updateNetworkMode(value: NetworkMode) = _uiState.update { it.copy(networkMode = value) }
    fun updateEnableAudio(value: Boolean) = _uiState.update { it.copy(enableAudio = value) }
    fun updateSharedStorageMode(value: SharedStorageMode) = _uiState.update { it.copy(sharedStorageMode = value) }
    fun updateKernelOptions(value: String) = _uiState.update { it.copy(kernelOptions = value) }
    fun updateExtraQemuArgs(value: String) = _uiState.update { it.copy(extraQemuArgs = value) }
    fun clearFeedback() = _uiState.update { it.copy(feedbackMessage = null) }

    fun onIsoPicked(uri: Uri) {
        safManager.persistReadPermission(uri)
        val meta = safManager.queryMetadata(uri)
        _uiState.update {
            it.copy(
                isoUri = meta.uriString,
                isoDisplayName = meta.displayName,
                isoSizeBytes = meta.sizeBytes
            )
        }
    }

    fun onDiskPickedViaSaf(uri: Uri) {
        safManager.persistReadWritePermission(uri)
        val meta = safManager.queryMetadata(uri)
        val format = if (meta.displayName.endsWith(".img", true)) DiskFormat.RAW else DiskFormat.QCOW2
        _uiState.update {
            it.copy(
                liveMode = false,
                diskPath = null,
                diskUri = meta.uriString,
                diskDisplayName = meta.displayName,
                diskFormat = format
            )
        }
    }

    fun onSelectPrivateDisk(file: File) {
        val format = if (file.extension.equals("img", true)) DiskFormat.RAW else DiskFormat.QCOW2
        _uiState.update {
            it.copy(
                liveMode = false,
                diskPath = file.absolutePath,
                diskUri = null,
                diskDisplayName = file.name,
                diskFormat = format
            )
        }
    }

    fun onSharedFolderPicked(uri: Uri) {
        safManager.persistReadWritePermission(uri)
        val meta = safManager.queryMetadata(uri)
        _uiState.update {
            it.copy(
                sharedStorageMode = SharedStorageMode.SHARED_FOLDER_VVFAT,
                sharedFolderUri = meta.uriString,
                sharedFolderName = meta.displayName
            )
        }
    }

    fun onExtraDiskPicked(uri: Uri) {
        safManager.persistReadWritePermission(uri)
        val meta = safManager.queryMetadata(uri)
        _uiState.update {
            it.copy(
                sharedStorageMode = SharedStorageMode.EXTRA_DISK,
                extraDiskUri = meta.uriString,
                extraDiskName = meta.displayName
            )
        }
    }

    fun createVirtualDisk(name: String, sizeGb: Int, format: DiskFormat) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                diskManager.createDisk(name, sizeGb, format)
            }.onSuccess { created ->
                _uiState.update {
                    it.copy(
                        liveMode = false,
                        diskPath = created.file.absolutePath,
                        diskUri = null,
                        diskDisplayName = "${created.file.name} (${created.sizeGb} GB)",
                        diskFormat = created.format,
                        diskSizeGb = created.sizeGb,
                        availablePrivateDisks = diskManager.listPrivateDisks(),
                        freeStorageGb = diskManager.getAvailableStorageGb(),
                        feedbackMessage = "Disco virtual ${created.file.name} criado com sucesso."
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(feedbackMessage = err.message ?: "Erro ao criar disco virtual.")
                }
            }
        }
    }

    fun previewCommandLine(): String {
        val s = _uiState.value
        val previewEntity = toEntity(s)
        val spec = QemuCommandBuilder.build(
            profile = previewEntity,
            isoFd = if (s.isoUri != null) 12 else null,
            diskFd = if (!s.liveMode && s.diskUri != null) 13 else null,
            extraDiskFd = if (s.sharedStorageMode == SharedStorageMode.EXTRA_DISK && s.extraDiskUri != null) 14 else null,
            sharedFatDirPath = if (s.sharedStorageMode == SharedStorageMode.SHARED_FOLDER_VVFAT && s.sharedFolderUri != null) "/data/user/0/.../shared" else null,
            qmpSocketPath = "/data/user/0/.../vm.qmp",
            biosDirPath = "/data/user/0/.../qemu_bios",
            kvmAvailable = s.capabilities?.kvmAvailable == true
        )
        return spec.toDisplayCommand()
    }

    fun saveProfile() {
        val s = _uiState.value
        if (s.name.isBlank()) {
            _uiState.update { it.copy(feedbackMessage = "Informe um nome para a máquina virtual.") }
            return
        }
        viewModelScope.launch {
            repository.save(toEntity(s))
            _uiState.update { it.copy(isSaved = true) }
        }
    }

    private fun toEntity(s: VmConfigUiState): VmProfileEntity {
        return VmProfileEntity(
            id = s.id,
            name = s.name.trim(),
            arch = s.arch.name,
            useKvmIfAvailable = s.useKvmIfAvailable,
            cpuCores = s.cpuCores,
            ramMb = s.ramMb,
            isoUri = s.isoUri,
            isoDisplayName = s.isoDisplayName,
            isoSizeBytes = s.isoSizeBytes,
            liveMode = s.liveMode,
            diskPath = s.diskPath,
            diskUri = s.diskUri,
            diskDisplayName = s.diskDisplayName,
            diskFormat = s.diskFormat.name,
            diskSizeGb = s.diskSizeGb,
            bootOrder = s.bootOrder.name,
            videoDriver = s.videoDriver.name,
            networkMode = s.networkMode.name,
            enableAudio = s.enableAudio,
            sharedStorageMode = s.sharedStorageMode.name,
            sharedFolderUri = s.sharedFolderUri,
            sharedFolderName = s.sharedFolderName,
            extraDiskPath = s.extraDiskName,
            extraDiskUri = s.extraDiskUri,
            kernelOptions = s.kernelOptions,
            extraQemuArgs = s.extraQemuArgs
        )
    }
}
