package com.example.ui.config

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.model.BootOrder
import com.example.data.model.NetworkMode
import com.example.data.model.SharedStorageMode
import com.example.data.model.VideoDriver
import com.example.data.model.VmArch
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VmConfigScreen(
    vmId: Long?,
    onNavigateBack: () -> Unit,
    viewModel: VmConfigViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var showDiskCreator by remember { mutableStateOf(false) }

    LaunchedEffect(vmId) {
        viewModel.loadProfile(vmId)
    }

    LaunchedEffect(state.isSaved) {
        if (state.isSaved) {
            onNavigateBack()
        }
    }

    LaunchedEffect(state.feedbackMessage) {
        state.feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedback()
        }
    }

    val isoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.onIsoPicked(it) }
    }

    val diskSafPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.onDiskPickedViaSaf(it) }
    }

    val sharedFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let { viewModel.onSharedFolderPicked(it) }
    }

    val extraDiskLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { viewModel.onExtraDiskPicked(it) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (state.id == 0L) "Nova Máquina Virtual" else "Configurar VM",
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("config_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cancel_config_button")
                    ) {
                        Text(stringResource(R.string.action_cancel))
                    }
                    Button(
                        onClick = { viewModel.saveProfile() },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_config_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.action_save))
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. Sistema & CPU/RAM
                ConfigSection(title = "1. Sistema, CPU e Memória") {
                    OutlinedTextField(
                        value = state.name,
                        onValueChange = viewModel::updateName,
                        label = { Text("Nome do perfil") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("vm_name_input")
                    )

                    Text("Arquitetura", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VmArch.entries.forEach { arch ->
                            FilterChip(
                                selected = state.arch == arch,
                                onClick = { viewModel.updateArch(arch) },
                                label = { Text(arch.displayName) },
                                modifier = Modifier.testTag("arch_chip_${arch.name.lowercase()}")
                            )
                        }
                    }

                    if (state.arch == VmArch.AARCH64) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Usar aceleração KVM", style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    text = if (state.capabilities?.kvmAvailable == true) {
                                        "/dev/kvm acessível neste dispositivo"
                                    } else {
                                        "/dev/kvm bloqueado pelo kernel (usará TCG)"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = state.useKvmIfAvailable,
                                onCheckedChange = viewModel::updateUseKvm,
                                modifier = Modifier.testTag("kvm_switch")
                            )
                        }
                    }

                    val maxCores = (state.capabilities?.cpuCores ?: 4).coerceIn(2, 8)
                    Text("Núcleos de CPU (vCPU): ${state.cpuCores}", style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = state.cpuCores.toFloat(),
                        onValueChange = { viewModel.updateCpuCores(it.roundToInt()) },
                        valueRange = 1f..maxCores.toFloat(),
                        steps = (maxCores - 2).coerceAtLeast(0),
                        modifier = Modifier.testTag("cpu_slider")
                    )

                    Text(
                        text = "Memória RAM: ${state.ramMb} MB (Máximo seguro: ${state.maxSafeRamMb} MB)",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = state.ramMb.toFloat(),
                        onValueChange = {
                            val snapped = ((it / 128f).roundToInt() * 128).coerceIn(256, state.maxSafeRamMb)
                            viewModel.updateRamMb(snapped)
                        },
                        valueRange = 256f..state.maxSafeRamMb.toFloat().coerceAtLeast(512f),
                        modifier = Modifier.testTag("ram_slider")
                    )
                }

                // 2. ISO & Ordem de Boot
                ConfigSection(title = "2. Imagem ISO e Ordem de Boot") {
                    Text(
                        text = state.isoDisplayName?.let {
                            val mb = state.isoSizeBytes / (1024L * 1024L)
                            "ISO: $it (${mb} MB)"
                        } ?: "Nenhuma ISO selecionada",
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (state.isoUri != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    OutlinedButton(
                        onClick = { isoPickerLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pick_iso_button")
                    ) {
                        Icon(Icons.Default.Album, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Selecionar ISO (Android-x86 / BlissOS / PrimeOS)")
                    }

                    Text("Ordem de Boot", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BootOrder.entries.forEach { order ->
                            FilterChip(
                                selected = state.bootOrder == order,
                                onClick = { viewModel.updateBootOrder(order) },
                                label = { Text(order.displayName) },
                                modifier = Modifier.testTag("boot_${order.name.lowercase()}")
                            )
                        }
                    }
                }

                // 3. Disco Virtual
                ConfigSection(title = "3. Disco Virtual e Modo Live") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Rodar em Modo Live (sem disco)", style = MaterialTheme.typography.bodyLarge)
                            Text(
                                text = "Inicia diretamente pela ISO sem gravar em disco virtual",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = state.liveMode,
                            onCheckedChange = viewModel::updateLiveMode,
                            modifier = Modifier.testTag("live_mode_switch")
                        )
                    }

                    if (!state.liveMode) {
                        Text(
                            text = "Disco selecionado: ${state.diskDisplayName ?: "Nenhum"}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { showDiskCreator = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("open_disk_creator_button")
                            ) {
                                Icon(Icons.Default.AddCircleOutline, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Criar Disco")
                            }
                            OutlinedButton(
                                onClick = { diskSafPickerLauncher.launch(arrayOf("*/*")) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pick_disk_saf_button")
                            ) {
                                Icon(Icons.Default.Storage, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Abrir via SAF")
                            }
                        }

                        if (state.availablePrivateDisks.isNotEmpty()) {
                            Text("Discos internos salvos:", style = MaterialTheme.typography.labelLarge)
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                state.availablePrivateDisks.forEach { diskFile ->
                                    FilterChip(
                                        selected = state.diskPath == diskFile.absolutePath,
                                        onClick = { viewModel.onSelectPrivateDisk(diskFile) },
                                        label = { Text(diskFile.name) }
                                    )
                                }
                            }
                        }
                    }
                }

                // 4. Vídeo, Áudio, Rede e Troca de Arquivos
                ConfigSection(title = "4. Vídeo, Áudio, Rede e Arquivos") {
                    Text("Controladora de Vídeo", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoDriver.entries.forEach { vga ->
                            FilterChip(
                                selected = state.videoDriver == vga,
                                onClick = { viewModel.updateVideoDriver(vga) },
                                label = { Text(vga.displayName) }
                            )
                        }
                    }

                    Text("Rede (NAT / User-mode)", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NetworkMode.entries.forEach { net ->
                            FilterChip(
                                selected = state.networkMode == net,
                                onClick = { viewModel.updateNetworkMode(net) },
                                label = { Text(net.displayName) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Habilitar Áudio (AC97 -> Android)", style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = state.enableAudio,
                            onCheckedChange = viewModel::updateEnableAudio,
                            modifier = Modifier.testTag("audio_switch")
                        )
                    }

                    Text("Troca de arquivos com a VM", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SharedStorageMode.entries.forEach { mode ->
                            FilterChip(
                                selected = state.sharedStorageMode == mode,
                                onClick = { viewModel.updateSharedStorageMode(mode) },
                                label = { Text(mode.displayName) }
                            )
                        }
                    }

                    when (state.sharedStorageMode) {
                        SharedStorageMode.SHARED_FOLDER_VVFAT -> {
                            OutlinedButton(
                                onClick = { sharedFolderLauncher.launch(null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pick_shared_folder_button")
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(state.sharedFolderName ?: "Escolher Pasta Compartilhada")
                            }
                        }
                        SharedStorageMode.EXTRA_DISK -> {
                            OutlinedButton(
                                onClick = { extraDiskLauncher.launch(arrayOf("*/*")) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pick_extra_disk_button")
                            ) {
                                Icon(Icons.Default.Storage, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(state.extraDiskName ?: "Selecionar Disco Extra (.img/.qcow2)")
                            }
                        }
                        SharedStorageMode.NONE -> Unit
                    }
                }

                // 5. Opções Avançadas e Preview QEMU
                ConfigSection(title = "5. Opções de Kernel e Comando QEMU") {
                    OutlinedTextField(
                        value = state.kernelOptions,
                        onValueChange = viewModel::updateKernelOptions,
                        label = { Text("Opções sugeridas de kernel (GRUB / -append)") },
                        placeholder = { Text("nomodeset DPI=160 vga=791") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("kernel_options_input")
                    )

                    OutlinedTextField(
                        value = state.extraQemuArgs,
                        onValueChange = viewModel::updateExtraQemuArgs,
                        label = { Text("Flags extras do QEMU (opcional)") },
                        placeholder = { Text("-rtc base=localtime") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("extra_qemu_args_input")
                    )

                    Text("Linha de comando gerada:", style = MaterialTheme.typography.labelLarge)
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = MaterialTheme.colorScheme.background,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = viewModel.previewCommandLine(),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showDiskCreator) {
        DiskCreatorDialog(
            freeStorageGb = state.freeStorageGb,
            onDismiss = { showDiskCreator = false },
            onCreateDisk = { name, sizeGb, format ->
                showDiskCreator = false
                viewModel.createVirtualDisk(name, sizeGb, format)
            }
        )
    }
}

@Composable
private fun ConfigSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = {
                Text(title, style = MaterialTheme.typography.titleMedium)
                content()
            }
        )
    }
}
