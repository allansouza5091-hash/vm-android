package com.example.ui.list

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.VmApplication
import com.example.data.local.VmProfileEntity
import com.example.data.model.DeviceCapabilities
import com.example.data.model.VmRuntimeState
import com.example.domain.DeviceCapabilityChecker
import com.example.service.VmServiceController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VmListViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VmApplication
    private val repository = app.repository
    private val capabilityChecker = DeviceCapabilityChecker(application)

    val profiles: StateFlow<List<VmProfileEntity>> = repository.profiles.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val runtimeState: StateFlow<VmRuntimeState> = VmServiceController.runtimeState

    private val _capabilities = MutableStateFlow(capabilityChecker.inspect())
    val capabilities: StateFlow<DeviceCapabilities> = _capabilities.asStateFlow()

    fun refreshCapabilities() {
        _capabilities.value = capabilityChecker.inspect()
    }

    fun duplicateProfile(profile: VmProfileEntity) {
        viewModelScope.launch {
            repository.duplicate(profile)
        }
    }

    fun deleteProfile(profile: VmProfileEntity, deletePrivateDisk: Boolean) {
        viewModelScope.launch {
            repository.delete(profile, deletePrivateDisk)
        }
    }

    fun startVm(profile: VmProfileEntity) {
        VmServiceController.startVm(getApplication(), profile.id)
    }
}
