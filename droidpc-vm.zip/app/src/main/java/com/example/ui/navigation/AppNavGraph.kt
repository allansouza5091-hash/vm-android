package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.about.AboutLicenseScreen
import com.example.ui.config.VmConfigScreen
import com.example.ui.list.VmListScreen
import com.example.ui.runner.VmRunnerScreen

object AppRoutes {
    const val VM_LIST = "vm_list"
    const val VM_CONFIG = "vm_config?vmId={vmId}"
    const val VM_RUNNER = "vm_runner/{vmId}"
    const val ABOUT = "about"

    fun configRoute(vmId: Long? = null): String =
        if (vmId == null) "vm_config" else "vm_config?vmId=$vmId"

    fun runnerRoute(vmId: Long): String = "vm_runner/$vmId"
}

@Composable
fun AppNavGraph() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = AppRoutes.VM_LIST
    ) {
        composable(AppRoutes.VM_LIST) {
            VmListScreen(
                onCreateVm = { navController.navigate(AppRoutes.configRoute(null)) },
                onEditVm = { vmId -> navController.navigate(AppRoutes.configRoute(vmId)) },
                onOpenRunner = { vmId -> navController.navigate(AppRoutes.runnerRoute(vmId)) },
                onOpenAbout = { navController.navigate(AppRoutes.ABOUT) }
            )
        }

        composable(
            route = AppRoutes.VM_CONFIG,
            arguments = listOf(
                navArgument("vmId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val rawId = backStackEntry.arguments?.getLong("vmId") ?: -1L
            VmConfigScreen(
                vmId = rawId.takeIf { it > 0L },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = AppRoutes.VM_RUNNER,
            arguments = listOf(
                navArgument("vmId") { type = NavType.LongType }
            )
        ) { backStackEntry ->
            val vmId = backStackEntry.arguments?.getLong("vmId") ?: 0L
            VmRunnerScreen(
                vmId = vmId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(AppRoutes.ABOUT) {
            AboutLicenseScreen(onNavigateBack = { navController.popBackStack() })
        }
    }
}
