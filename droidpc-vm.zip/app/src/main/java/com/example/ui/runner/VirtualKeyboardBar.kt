package com.example.ui.runner

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AssistChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.vnc.VncKeyMapper

@Composable
fun VirtualKeyboardBar(
    onKeyTap: (Int) -> Unit,
    onCtrlAltDel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current
    var imeBuffer by remember { mutableStateOf(" ") }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Campo invisível para capturar entrada do teclado virtual (IME) do Android
            BasicTextField(
                value = imeBuffer,
                onValueChange = { updated ->
                    when {
                        updated.length < imeBuffer.length -> onKeyTap(VncKeyMapper.KEYSYM_BACKSPACE)
                        updated.length > imeBuffer.length -> {
                            val added = updated.substring(imeBuffer.length)
                            for (ch in added) {
                                when (ch) {
                                    '\n' -> onKeyTap(VncKeyMapper.KEYSYM_RETURN)
                                    '\t' -> onKeyTap(VncKeyMapper.KEYSYM_TAB)
                                    else -> {
                                        val code = ch.code
                                        if (code in 0x20..0x7E) {
                                            onKeyTap(code)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    imeBuffer = " "
                },
                modifier = Modifier
                    .size(1.dp)
                    .alpha(0f)
                    .focusRequester(focusRequester)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AssistChip(
                    onClick = {
                        focusRequester.requestFocus()
                        keyboardController?.show()
                    },
                    label = { Text("Teclado IME") },
                    modifier = Modifier.testTag("show_ime_keyboard_chip")
                )
                AssistChip(
                    onClick = onCtrlAltDel,
                    label = { Text("Ctrl+Alt+Del") },
                    modifier = Modifier.testTag("send_ctrl_alt_del_chip")
                )
                AssistChip(
                    onClick = { onKeyTap(VncKeyMapper.KEYSYM_ESCAPE) },
                    label = { Text("Esc") }
                )
                AssistChip(
                    onClick = { onKeyTap(VncKeyMapper.KEYSYM_TAB) },
                    label = { Text("Tab") }
                )
                AssistChip(
                    onClick = { onKeyTap(VncKeyMapper.KEYSYM_RETURN) },
                    label = { Text("Enter") }
                )
                AssistChip(
                    onClick = { onKeyTap(VncKeyMapper.KEYSYM_SUPER_L) },
                    label = { Text("Home/Win") }
                )
                AssistChip(
                    onClick = { onKeyTap(VncKeyMapper.KEYSYM_UP) },
                    label = { Text("↑") }
                )
                AssistChip(
                    onClick = { onKeyTap(VncKeyMapper.KEYSYM_DOWN) },
                    label = { Text("↓") }
                )
                AssistChip(
                    onClick = { onKeyTap(VncKeyMapper.KEYSYM_LEFT) },
                    label = { Text("←") }
                )
                AssistChip(
                    onClick = { onKeyTap(VncKeyMapper.KEYSYM_RIGHT) },
                    label = { Text("→") }
                )
            }
        }
    }
}
