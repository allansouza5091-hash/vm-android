package com.example.ui.config

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.DiskFormat
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun DiskCreatorDialog(
    freeStorageGb: Double,
    onDismiss: () -> Unit,
    onCreateDisk: (name: String, sizeGb: Int, format: DiskFormat) -> Unit
) {
    var diskName by remember { mutableStateOf("android_disk_${System.currentTimeMillis() % 10000}") }
    var selectedFormat by remember { mutableStateOf(DiskFormat.QCOW2) }
    var sizeGb by remember { mutableIntStateOf(8) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Criar Disco Virtual") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = diskName,
                    onValueChange = { diskName = it },
                    label = { Text("Nome do arquivo") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("disk_name_input")
                )

                Text("Formato do disco", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedFormat == DiskFormat.QCOW2,
                        onClick = { selectedFormat = DiskFormat.QCOW2 },
                        label = { Text(".qcow2 (Dinâmico + SaveVM)") },
                        modifier = Modifier.testTag("disk_format_qcow2")
                    )
                    FilterChip(
                        selected = selectedFormat == DiskFormat.RAW,
                        onClick = { selectedFormat = DiskFormat.RAW },
                        label = { Text(".img (Raw)") },
                        modifier = Modifier.testTag("disk_format_raw")
                    )
                }

                Text(
                    text = "Tamanho máximo virtual: $sizeGb GB",
                    style = MaterialTheme.typography.labelLarge
                )
                Slider(
                    value = sizeGb.toFloat(),
                    onValueChange = { sizeGb = it.roundToInt().coerceIn(2, 64) },
                    valueRange = 2f..64f,
                    steps = 30,
                    modifier = Modifier.testTag("disk_size_slider")
                )

                Text(
                    text = String.format(
                        Locale.getDefault(),
                        "Espaço livre interno: %.1f GB. Arquivos .qcow2 crescem sob demanda.",
                        freeStorageGb
                    ),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onCreateDisk(diskName, sizeGb, selectedFormat) },
                modifier = Modifier.testTag("confirm_create_disk_button")
            ) {
                Text("Criar Disco")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
