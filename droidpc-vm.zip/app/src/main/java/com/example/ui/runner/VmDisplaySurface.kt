package com.example.ui.runner

import android.view.KeyEvent as AndroidKeyEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.example.vnc.VncFrameState
import com.example.vnc.VncKeyMapper
import kotlin.math.abs
import kotlin.math.roundToInt

private data class DisplayViewport(
    val offsetX: Int = 0,
    val offsetY: Int = 0,
    val drawWidth: Int = 1,
    val drawHeight: Int = 1
)

@Composable
fun VmDisplaySurface(
    frameState: VncFrameState,
    dragSelectEnabled: Boolean,
    onPointerEvent: (guestX: Int, guestY: Int, buttonMask: Int) -> Unit,
    onHardwareKeyEvent: (down: Boolean, keySym: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var containerSize by remember { mutableStateOf(IntSize(1, 1)) }

    fun computeViewport(): DisplayViewport {
        val cw = containerSize.width.coerceAtLeast(1)
        val ch = containerSize.height.coerceAtLeast(1)
        val fw = frameState.width.coerceAtLeast(1)
        val fh = frameState.height.coerceAtLeast(1)
        val scale = minOf(cw.toFloat() / fw.toFloat(), ch.toFloat() / fh.toFloat())
        val dw = (fw * scale).roundToInt().coerceAtLeast(1)
        val dh = (fh * scale).roundToInt().coerceAtLeast(1)
        val ox = ((cw - dw) / 2f).roundToInt()
        val oy = ((ch - dh) / 2f).roundToInt()
        return DisplayViewport(ox, oy, dw, dh)
    }

    fun mapToGuest(pos: Offset): Pair<Int, Int> {
        val vp = computeViewport()
        val normX = ((pos.x - vp.offsetX) / vp.drawWidth.toFloat()).coerceIn(0f, 1f)
        val normY = ((pos.y - vp.offsetY) / vp.drawHeight.toFloat()).coerceIn(0f, 1f)
        val gx = (normX * (frameState.width - 1)).roundToInt().coerceIn(0, frameState.width - 1)
        val gy = (normY * (frameState.height - 1)).roundToInt().coerceIn(0, frameState.height - 1)
        return gx to gy
    }

    Box(
        modifier = modifier
            .background(Color.Black)
            .focusable()
            .onSizeChanged { containerSize = it }
            .onPreviewKeyEvent { composeKeyEvent ->
                val native = composeKeyEvent.nativeKeyEvent
                val keySym = VncKeyMapper.mapAndroidKeyEvent(native) ?: return@onPreviewKeyEvent false
                when (native.action) {
                    AndroidKeyEvent.ACTION_DOWN -> {
                        onHardwareKeyEvent(true, keySym)
                        true
                    }
                    AndroidKeyEvent.ACTION_UP -> {
                        onHardwareKeyEvent(false, keySym)
                        true
                    }
                    else -> false
                }
            }
            .pointerInput(frameState.width, frameState.height, dragSelectEnabled) {
                awaitEachGesture {
                    val firstDown = awaitFirstDown(requireUnconsumed = false)
                    val isMouse = firstDown.type == PointerType.Mouse
                    val startPos = firstDown.position
                    val downTimeMs = System.currentTimeMillis()
                    var moved = false
                    var longPressTriggered = false
                    var twoFingerScrolled = false
                    var lastScrollY = startPos.y

                    if (isMouse) {
                        val (gx, gy) = mapToGuest(startPos)
                        onPointerEvent(gx, gy, 1)
                    } else if (dragSelectEnabled) {
                        val (gx, gy) = mapToGuest(startPos)
                        onPointerEvent(gx, gy, 1)
                    }

                    while (true) {
                        val event = awaitPointerEvent()

                        // Mouse USB/BT com roda de rolagem ou botão direito
                        if (event.type == PointerEventType.Scroll) {
                            val change = event.changes.firstOrNull() ?: continue
                            val (gx, gy) = mapToGuest(change.position)
                            val deltaY = change.scrollDelta.y
                            if (deltaY < 0f) {
                                onPointerEvent(gx, gy, 8)
                                onPointerEvent(gx, gy, 0)
                            } else if (deltaY > 0f) {
                                onPointerEvent(gx, gy, 16)
                                onPointerEvent(gx, gy, 0)
                            }
                            continue
                        }

                        if (event.buttons.isSecondaryPressed) {
                            val change = event.changes.firstOrNull() ?: continue
                            val (gx, gy) = mapToGuest(change.position)
                            onPointerEvent(gx, gy, 4)
                            onPointerEvent(gx, gy, 0)
                            break
                        }

                        val pressedChanges = event.changes.filter { it.pressed }
                        if (pressedChanges.isEmpty()) {
                            val lastPos = event.changes.firstOrNull()?.position ?: startPos
                            val (gx, gy) = mapToGuest(lastPos)
                            val elapsed = System.currentTimeMillis() - downTimeMs

                            if (!twoFingerScrolled && !longPressTriggered) {
                                if (isMouse || dragSelectEnabled) {
                                    onPointerEvent(gx, gy, 0)
                                } else if (!moved && elapsed >= 520L) {
                                    // Toque longo = botão direito
                                    onPointerEvent(gx, gy, 4)
                                    onPointerEvent(gx, gy, 0)
                                } else if (!moved) {
                                    // Toque curto = clique esquerdo
                                    onPointerEvent(gx, gy, 1)
                                    onPointerEvent(gx, gy, 0)
                                } else {
                                    onPointerEvent(gx, gy, 0)
                                }
                            }
                            break
                        }

                        if (pressedChanges.size >= 2) {
                            // Dois dedos = rolagem vertical (botões 4/5 RFB)
                            twoFingerScrolled = true
                            val avgY = pressedChanges.map { it.position.y }.average().toFloat()
                            val avgX = pressedChanges.map { it.position.x }.average().toFloat()
                            val dy = avgY - lastScrollY
                            if (abs(dy) > 18f) {
                                val (gx, gy) = mapToGuest(Offset(avgX, avgY))
                                val mask = if (dy > 0f) 8 else 16
                                onPointerEvent(gx, gy, mask)
                                onPointerEvent(gx, gy, 0)
                                lastScrollY = avgY
                            }
                        } else {
                            val curr = pressedChanges.first()
                            val dist = (curr.position - startPos).getDistance()
                            if (dist > 14f) {
                                moved = true
                            }
                            val elapsed = System.currentTimeMillis() - downTimeMs
                            if (!isMouse && !dragSelectEnabled && !moved && !longPressTriggered && elapsed >= 520L) {
                                longPressTriggered = true
                                val (gx, gy) = mapToGuest(curr.position)
                                onPointerEvent(gx, gy, 4)
                                onPointerEvent(gx, gy, 0)
                            } else if (moved) {
                                val (gx, gy) = mapToGuest(curr.position)
                                val mask = if (isMouse || dragSelectEnabled) 1 else 0
                                onPointerEvent(gx, gy, mask)
                            }
                        }
                    }
                }
            }
            .testTag("vm_display_surface")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val img = frameState.imageBitmap
            if (img != null) {
                val vp = computeViewport()
                drawImage(
                    image = img,
                    dstOffset = IntOffset(vp.offsetX, vp.offsetY),
                    dstSize = IntSize(vp.drawWidth, vp.drawHeight),
                    filterQuality = FilterQuality.Medium
                )
            } else {
                drawRect(color = Color(0xFF05080C))
            }
        }
    }
}
