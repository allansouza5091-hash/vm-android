package com.example.ui.runner

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.model.TelemetrySnapshot
import com.example.data.model.VmRunStatus

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VmRunnerScreen(
    vmId: Long,
    onNavigateBack: () -> Unit,
    viewModel: VmRunnerViewModel = viewModel()
) {
    val runtime by viewModel.runtimeState.collectAsStateWithLifecycle()
    val vncFrame by viewModel.vncFrameState.collectAsStateWithLifecycle()

    var showLogsSheet by remember { mutableStateOf(false) }
    var dragSelectMode by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = runtime.activeVmName.ifBlank { "VM #$vmId" },
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = runtime.statusMessage,
                            style = MaterialTheme.typography.labelSmall,
                            color = when (runtime.status) {
                                VmRunStatus.RUNNING -> MaterialTheme.colorScheme.secondary
                                VmRunStatus.PAUSED -> MaterialTheme.colorScheme.tertiary
                                VmRunStatus.ERROR -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("runner_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showLogsSheet = true },
                        modifier = Modifier.testTag("open_logs_button")
                    ) {
                        Icon(Icons.Default.Terminal, contentDescription = stringResource(R.string.action_logs))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            TelemetryStrip(telemetry = runtime.telemetry)

            if (runtime.telemetry.isLowBatteryWarning || runtime.telemetry.isThermalThrottling) {
                ThermalBatteryAlertBanner(telemetry = runtime.telemetry)
            }

            // Barra de ações de energia, snapshot e modo de toque
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = viewModel::togglePause,
                    modifier = Modifier.testTag("pause_resume_button")
                ) {
                    Icon(
                        imageVector = if (runtime.status == VmRunStatus.PAUSED) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        if (runtime.status == VmRunStatus.PAUSED) {
                            stringResource(R.string.action_resume)
                        } else {
                            stringResource(R.string.action_pause)
                        }
                    )
                }

                OutlinedButton(
                    onClick = viewModel::resetVm,
                    modifier = Modifier.testTag("reset_vm_button")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.action_reset))
                }

                OutlinedButton(
                    onClick = viewModel::powerdownVm,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("powerdown_vm_button")
                ) {
                    Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.action_powerdown))
                }

                OutlinedButton(
                    onClick = { viewModel.saveState() },
                    modifier = Modifier.testTag("save_state_button")
                ) {
                    Icon(Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.action_save_state))
                }

                OutlinedButton(
                    onClick = { viewModel.loadState() },
                    modifier = Modifier.testTag("load_state_button")
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.action_load_state))
                }

                FilterChip(
                    selected = dragSelectMode,
                    onClick = { dragSelectMode = !dragSelectMode },
                    leadingIcon = {
                        Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    label = { Text(if (dragSelectMode) "Arrastar=Clique" else "Toque=Mouse") },
                    modifier = Modifier.testTag("drag_mode_chip")
                )
            }

            // Viewport da VM (VNC) ou diagnóstico se o .so ainda não foi compilado
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                VmDisplaySurface(
                    frameState = vncFrame,
                    dragSelectEnabled = dragSelectMode,
                    onPointerEvent = viewModel::sendPointer,
                    onHardwareKeyEvent = viewModel::sendKeyEvent,
                    modifier = Modifier.fillMaxSize()
                )

                if (runtime.nativeEngineMissing || runtime.status == VmRunStatus.ERROR) {
                    MissingEngineOverlay(
                        message = runtime.statusMessage,
                        onOpenLogs = { showLogsSheet = true },
                        onBack = onNavigateBack
                    )
                } else if (!vncFrame.connected && runtime.status == VmRunStatus.RUNNING) {
                    Surface(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                        shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Text(
                            text = "Conectando ao display VNC interno (127.0.0.1:${runtime.vncPort})...",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            }

            VirtualKeyboardBar(
                onKeyTap = viewModel::sendKeyTap,
                onCtrlAltDel = viewModel::sendCtrlAltDel
            )
        }
    }

    if (showLogsSheet) {
        VmLogsBottomSheet(
            commandLine = runtime.lastCommandLine,
            logs = runtime.logs,
            onDismiss = { showLogsSheet = false }
        )
    }
}

@Composable
private fun TelemetryStrip(telemetry: TelemetrySnapshot) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CPU ${telemetry.processCpuPercent}%",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "RAM livre ${telemetry.deviceFreeRamMb} MB",
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                text = "${telemetry.batteryTempCelsius}°C (${telemetry.thermalStatusLabel})",
                style = MaterialTheme.typography.labelMedium,
                color = if (telemetry.isThermalThrottling) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "${telemetry.batteryPercent}%${if (telemetry.batteryCharging) "⚡" else ""}",
                style = MaterialTheme.typography.labelMedium,
                color = if (telemetry.isLowBatteryWarning) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
            )
        }
    }
}

@Composable
private fun ThermalBatteryAlertBanner(telemetry: TelemetrySnapshot) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = if (telemetry.isLowBatteryWarning) Icons.Default.BatteryAlert else Icons.Default.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = buildString {
                    if (telemetry.isLowBatteryWarning) {
                        append("Bateria baixa (${telemetry.batteryPercent}%): conecte o carregador ou salve o estado. ")
                    }
                    if (telemetry.isThermalThrottling) {
                        append("Aquecimento elevado (${telemetry.batteryTempCelsius}°C): possível redução de clock.")
                    }
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
        }
    }
}

@Composable
private fun MissingEngineOverlay(
    message: String,
    onOpenLogs: () -> Unit,
    onBack: () -> Unit
) {
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error),
        modifier = Modifier.padding(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Motor QEMU não empacotado neste APK",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.error
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "Execute native-build/build_deps.sh e native-build/build_qemu.sh em Linux com Android NDK para gerar libqemu-system-x86_64.so em app/src/main/jniLibs/arm64-v8a/.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onOpenLogs,
                    modifier = Modifier.testTag("overlay_open_logs_button")
                ) {
                    Text("Ver Comando & Logs")
                }
                Button(
                    onClick = onBack,
                    modifier = Modifier.testTag("overlay_back_button")
                ) {
                    Text("Voltar")
                }
            }
        }
    }
}
