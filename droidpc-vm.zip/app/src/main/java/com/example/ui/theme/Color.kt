package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBackground = Color(0xFF0A0E14)
val ObsidianSurface = Color(0xFF121821)
val ObsidianSurfaceVariant = Color(0xFF1A2330)
val ObsidianOutline = Color(0xFF2B3748)

val CyanPrimary = Color(0xFF22D3EE)
val CyanOnPrimary = Color(0xFF00242A)
val CyanContainer = Color(0xFF0A3A44)
val CyanOnContainer = Color(0xFFB7F4FF)

val EmeraldSecondary = Color(0xFF10B981)
val EmeraldOnSecondary = Color(0xFF002619)
val EmeraldContainer = Color(0xFF083B2B)
val EmeraldOnContainer = Color(0xFFA7F3D0)

val AmberTertiary = Color(0xFFF59E0B)
val AmberOnTertiary = Color(0xFF2E1B00)
val AmberContainer = Color(0xFF472C00)
val AmberOnContainer = Color(0xFFFDE68A)

val ErrorRed = Color(0xFFEF4444)
val ErrorContainerDark = Color(0xFF5A1616)
val OnErrorContainerDark = Color(0xFFFECACA)

val TextPrimaryDark = Color(0xFFE6EDF5)
val TextSecondaryDark = Color(0xFF94A3B8)

// Light palette fallback
val LightBackground = Color(0xFFF4F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6ECF2)
val LightOutline = Color(0xFFCBD5E1)
val CyanPrimaryLight = Color(0xFF0891B2)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
