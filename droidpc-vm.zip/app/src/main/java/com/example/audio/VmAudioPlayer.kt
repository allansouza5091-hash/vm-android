package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.example.nativebridge.QemuNativeBridge

class VmAudioPlayer {
    private var audioTrack: AudioTrack? = null
    private var usingNativeAAudio = false

    fun start(sampleRate: Int = 44100) {
        if (QemuNativeBridge.initAudio(sampleRate, 2)) {
            usingNativeAAudio = true
            return
        }

        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_STEREO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4096)

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(minBuf * 2)
            .build()
            .also { it.play() }
    }

    fun writePcm(data: ByteArray, length: Int) {
        if (length <= 0) return
        if (usingNativeAAudio) {
            QemuNativeBridge.writeAudioPcm(data, length)
        } else {
            audioTrack?.write(data, 0, length)
        }
    }

    fun stop() {
        if (usingNativeAAudio) {
            QemuNativeBridge.closeAudio()
            usingNativeAAudio = false
        }
        runCatching {
            audioTrack?.stop()
            audioTrack?.release()
        }
        audioTrack = null
    }
}
