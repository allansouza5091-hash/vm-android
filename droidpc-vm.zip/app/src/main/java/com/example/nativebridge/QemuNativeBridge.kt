package com.example.nativebridge

import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

data class NativeExitEvent(
    val exitCode: Int,
    val message: String
)

object QemuNativeBridge {
    private const val TAG = "QemuNativeBridge"

    val isBridgeLoaded: Boolean = runCatching {
        System.loadLibrary("qemu_bridge")
        true
    }.getOrElse { error ->
        Log.w(TAG, "libqemu_bridge.so não carregada neste build: ${error.message}")
        false
    }

    private val _logs = MutableSharedFlow<String>(extraBufferCapacity = 256)
    val logs: SharedFlow<String> = _logs.asSharedFlow()

    private val _exitEvents = MutableSharedFlow<NativeExitEvent>(extraBufferCapacity = 8)
    val exitEvents: SharedFlow<NativeExitEvent> = _exitEvents.asSharedFlow()

    fun isEngineAvailable(libraryName: String): Boolean {
        if (!isBridgeLoaded) return false
        return runCatching { nativeIsEngineAvailable(libraryName) }.getOrDefault(false)
    }

    fun startVm(libraryName: String, args: List<String>, ownedFds: IntArray): Boolean {
        if (!isBridgeLoaded) {
            _logs.tryEmit("ERRO: libqemu_bridge.so não empacotada. Compile com NDK/CMake e jniLibs/arm64-v8a.")
            return false
        }
        return runCatching {
            nativeStartVm(libraryName, args.toTypedArray(), ownedFds)
        }.getOrElse { err ->
            _logs.tryEmit("ERRO JNI ao iniciar VM: ${err.message}")
            false
        }
    }

    fun sendQmpCommand(socketPath: String, jsonCommand: String): Result<String> {
        if (!isBridgeLoaded) {
            return Result.failure(IllegalStateException("Ponte nativa não carregada."))
        }
        return runCatching {
            val raw = nativeSendQmpCommand(socketPath, jsonCommand)
            if (raw.startsWith("OK:")) {
                raw.removePrefix("OK:")
            } else {
                throw IllegalStateException(raw.removePrefix("ERR:"))
            }
        }
    }

    fun isVmRunning(): Boolean {
        if (!isBridgeLoaded) return false
        return runCatching { nativeIsVmRunning() }.getOrDefault(false)
    }

    fun initAudio(sampleRate: Int = 44100, channels: Int = 2): Boolean {
        if (!isBridgeLoaded) return false
        return runCatching { nativeInitAudio(sampleRate, channels) }.getOrDefault(false)
    }

    fun writeAudioPcm(pcmData: ByteArray, lengthBytes: Int): Int {
        if (!isBridgeLoaded) return 0
        return runCatching { nativeWriteAudioPcm(pcmData, lengthBytes) }.getOrDefault(-1)
    }

    fun closeAudio() {
        if (!isBridgeLoaded) return
        runCatching { nativeCloseAudio() }
    }

    // Chamado pelo C++ (qemu_jni.cpp)
    @Suppress("unused")
    fun onNativeLog(line: String) {
        _logs.tryEmit(line)
    }

    // Chamado pelo C++ (qemu_jni.cpp)
    @Suppress("unused")
    fun onNativeVmExit(exitCode: Int, message: String) {
        _exitEvents.tryEmit(NativeExitEvent(exitCode, message))
    }

    private external fun nativeIsEngineAvailable(libraryName: String): Boolean
    private external fun nativeStartVm(
        libraryName: String,
        argsArray: Array<String>,
        ownedFds: IntArray
    ): Boolean

    private external fun nativeSendQmpCommand(socketPath: String, jsonCommand: String): String
    private external fun nativeIsVmRunning(): Boolean
    private external fun nativeInitAudio(sampleRate: Int, channels: Int): Boolean
    private external fun nativeWriteAudioPcm(pcmData: ByteArray, lengthBytes: Int): Int
    private external fun nativeCloseAudio()
}
