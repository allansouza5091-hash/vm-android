package com.example.nativebridge

import android.net.LocalSocket
import android.net.LocalSocketAddress
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class QmpController {

    suspend fun pauseVm(socketPath: String): Result<String> =
        execute(socketPath, """{"execute":"stop"}""")

    suspend fun resumeVm(socketPath: String): Result<String> =
        execute(socketPath, """{"execute":"cont"}""")

    suspend fun resetVm(socketPath: String): Result<String> =
        execute(socketPath, """{"execute":"system_reset"}""")

    suspend fun powerdownVm(socketPath: String): Result<String> =
        execute(socketPath, """{"execute":"system_powerdown"}""")

    suspend fun quitVm(socketPath: String): Result<String> =
        execute(socketPath, """{"execute":"quit"}""")

    suspend fun sendCtrlAltDel(socketPath: String): Result<String> =
        execute(
            socketPath,
            """{"execute":"send-key","arguments":{"keys":[{"type":"qcode","data":"ctrl"},{"type":"qcode","data":"alt"},{"type":"qcode","data":"delete"}]}}"""
        )

    suspend fun saveState(socketPath: String, tag: String): Result<String> {
        val safeTag = tag.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "quick_save" }
        return execute(
            socketPath,
            """{"execute":"human-monitor-command","arguments":{"command-line":"savevm $safeTag"}}"""
        )
    }

    suspend fun loadState(socketPath: String, tag: String): Result<String> {
        val safeTag = tag.replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "quick_save" }
        return execute(
            socketPath,
            """{"execute":"human-monitor-command","arguments":{"command-line":"loadvm $safeTag"}}"""
        )
    }

    suspend fun execute(socketPath: String, jsonCommand: String): Result<String> =
        withContext(Dispatchers.IO) {
            if (socketPath.isBlank()) {
                return@withContext Result.failure(IllegalArgumentException("Socket QMP não configurado."))
            }

            // Tenta via LocalSocket do Android primeiro (funciona independente da bridge JNI)
            val localSocketResult = runCatching {
                LocalSocket().use { socket ->
                    socket.connect(
                        LocalSocketAddress(socketPath, LocalSocketAddress.Namespace.FILESYSTEM)
                    )
                    socket.soTimeout = 3000
                    val reader = BufferedReader(InputStreamReader(socket.inputStream, StandardCharsets.UTF_8))
                    val out = socket.outputStream

                    // Banner inicial QMP
                    reader.readLine()
                    out.write("{\"execute\":\"qmp_capabilities\"}\r\n".toByteArray(StandardCharsets.UTF_8))
                    out.flush()
                    reader.readLine()

                    out.write("$jsonCommand\r\n".toByteArray(StandardCharsets.UTF_8))
                    out.flush()

                    var response = ""
                    repeat(5) {
                        val line = reader.readLine() ?: return@repeat
                        response = line
                        if (!line.contains("\"event\"")) {
                            return@runCatching response
                        }
                    }
                    response
                }
            }

            if (localSocketResult.isSuccess) {
                localSocketResult
            } else {
                QemuNativeBridge.sendQmpCommand(socketPath, jsonCommand)
            }
        }
}
