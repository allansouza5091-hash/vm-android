package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.VmRepository

class VmApplication : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val repository: VmRepository by lazy { VmRepository(database.vmProfileDao()) }
}
