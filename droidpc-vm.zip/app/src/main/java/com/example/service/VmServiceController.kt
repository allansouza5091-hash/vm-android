package com.example.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.data.model.VmRunStatus
import com.example.data.model.VmRuntimeState
import com.example.vnc.VncFrameState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object VmServiceController {
    private val _runtimeState = MutableStateFlow(VmRuntimeState())
    val runtimeState: StateFlow<VmRuntimeState> = _runtimeState.asStateFlow()

    private val _vncFrameState = MutableStateFlow(VncFrameState())
    val vncFrameState: StateFlow<VncFrameState> = _vncFrameState.asStateFlow()

    internal var activeService: VmForegroundService? = null

    fun startVm(context: Context, vmId: Long) {
        val intent = Intent(context, VmForegroundService::class.java).apply {
            action = VmForegroundService.ACTION_START_VM
            putExtra(VmForegroundService.EXTRA_VM_ID, vmId)
        }
        ContextCompat.startForegroundService(context, intent)
    }

    fun pauseOrResume(context: Context) {
        val intent = Intent(context, VmForegroundService::class.java).apply {
            action = VmForegroundService.ACTION_TOGGLE_PAUSE
        }
        context.startService(intent)
    }

    fun resetVm(context: Context) {
        val intent = Intent(context, VmForegroundService::class.java).apply {
            action = VmForegroundService.ACTION_RESET_VM
        }
        context.startService(intent)
    }

    fun powerdownVm(context: Context) {
        val intent = Intent(context, VmForegroundService::class.java).apply {
            action = VmForegroundService.ACTION_POWERDOWN_VM
        }
        context.startService(intent)
    }

    fun forceStopVm(context: Context) {
        val intent = Intent(context, VmForegroundService::class.java).apply {
            action = VmForegroundService.ACTION_FORCE_STOP_VM
        }
        context.startService(intent)
    }

    fun saveSnapshot(tag: String = "quick_save") {
        activeService?.saveVmState(tag)
    }

    fun loadSnapshot(tag: String = "quick_save") {
        activeService?.loadVmState(tag)
    }

    fun sendCtrlAltDel() {
        activeService?.sendCtrlAltDel()
    }

    fun sendPointer(x: Int, y: Int, buttonMask: Int) {
        activeService?.sendPointer(x, y, buttonMask)
    }

    fun sendKeyEvent(down: Boolean, keySym: Int) {
        activeService?.sendKeyEvent(down, keySym)
    }

    fun sendKeyTap(keySym: Int) {
        activeService?.sendKeyTap(keySym)
    }

    internal fun updateState(transform: (VmRuntimeState) -> VmRuntimeState) {
        _runtimeState.update(transform)
    }

    internal fun appendLog(line: String) {
        _runtimeState.update { current ->
            val updated = (current.logs + line).takeLast(300)
            current.copy(logs = updated)
        }
    }

    internal fun updateVncFrame(frame: VncFrameState) {
        _vncFrameState.value = frame
    }

    fun resetErrorState() {
        _runtimeState.update {
            if (it.status == VmRunStatus.ERROR || it.status == VmRunStatus.STOPPED) {
                VmRuntimeState()
            } else {
                it
            }
        }
    }
}
