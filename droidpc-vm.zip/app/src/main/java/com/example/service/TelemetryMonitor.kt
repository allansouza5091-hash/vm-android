package com.example.service

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.example.data.model.TelemetrySnapshot
import java.io.RandomAccessFile

class TelemetryMonitor(private val context: Context) {
    private var lastProcessCpuTimeMs: Long = 0L
    private var lastWallTimeMs: Long = 0L

    fun collect(): TelemetrySnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val freeMb = memInfo.availMem / (1024L * 1024L)
        val totalMb = memInfo.totalMem / (1024L * 1024L)

        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = tempTenths / 10f

        val (thermalLabel, throttling) = readThermalStatus()
        val cpuPercent = readProcessCpuPercent()

        return TelemetrySnapshot(
            processCpuPercent = cpuPercent,
            deviceFreeRamMb = freeMb,
            deviceTotalRamMb = totalMb,
            batteryPercent = batteryPct,
            batteryCharging = charging,
            batteryTempCelsius = tempC,
            thermalStatusLabel = thermalLabel,
            isThermalThrottling = throttling || tempC >= 43f,
            isLowBatteryWarning = !charging && batteryPct <= 20
        )
    }

    private fun readThermalStatus(): Pair<String, Boolean> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return "Normal" to false
        }
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal" to false
            PowerManager.THERMAL_STATUS_LIGHT -> "Morno" to false
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderado" to false
            PowerManager.THERMAL_STATUS_SEVERE -> "Alto (Throttling)" to true
            PowerManager.THERMAL_STATUS_CRITICAL,
            PowerManager.THERMAL_STATUS_EMERGENCY,
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Crítico" to true
            else -> "Normal" to false
        }
    }

    private fun readProcessCpuPercent(): Int {
        return runCatching {
            val statLine = RandomAccessFile("/proc/self/stat", "r").use { it.readLine() } ?: return 0
            val rparen = statLine.lastIndexOf(')')
            if (rparen <= 0) return 0
            val fields = statLine.substring(rparen + 2).split(' ')
            val utime = fields[11].toLong()
            val stime = fields[12].toLong()
            val totalTicks = utime + stime
            val nowMs = System.currentTimeMillis()
            val totalCpuMs = totalTicks * 10L // USER_HZ ~ 100

            val result = if (lastWallTimeMs > 0L && nowMs > lastWallTimeMs) {
                val deltaCpu = (totalCpuMs - lastProcessCpuTimeMs).coerceAtLeast(0L)
                val deltaWall = nowMs - lastWallTimeMs
                val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
                ((deltaCpu * 100L) / (deltaWall * cores)).toInt().coerceIn(0, 100)
            } else {
                0
            }
            lastProcessCpuTimeMs = totalCpuMs
            lastWallTimeMs = nowMs
            result
        }.getOrDefault(0)
    }
}
