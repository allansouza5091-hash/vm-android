package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.VmAudioPlayer
import com.example.data.local.AppDatabase
import com.example.data.local.VmProfileEntity
import com.example.data.model.SharedStorageMode
import com.example.data.model.VmArch
import com.example.data.model.VmRunStatus
import com.example.data.repository.VmRepository
import com.example.domain.DeviceCapabilityChecker
import com.example.domain.QemuCommandBuilder
import com.example.domain.SafFileManager
import com.example.nativebridge.QemuNativeBridge
import com.example.nativebridge.QmpController
import com.example.vnc.VncClient
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VmForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "droidpc_vm_channel"
        const val NOTIFICATION_ID = 4041
        const val ACTION_START_VM = "com.example.action.START_VM"
        const val ACTION_TOGGLE_PAUSE = "com.example.action.TOGGLE_PAUSE"
        const val ACTION_RESET_VM = "com.example.action.RESET_VM"
        const val ACTION_POWERDOWN_VM = "com.example.action.POWERDOWN_VM"
        const val ACTION_FORCE_STOP_VM = "com.example.action.FORCE_STOP_VM"
        const val EXTRA_VM_ID = "extra_vm_id"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var wakeLock: PowerManager.WakeLock? = null
    private var telemetryJob: Job? = null
    private var vncObserverJob: Job? = null
    private var nativeCollectorJob: Job? = null

    private lateinit var repository: VmRepository
    private lateinit var safFileManager: SafFileManager
    private lateinit var telemetryMonitor: TelemetryMonitor
    private lateinit var capabilityChecker: DeviceCapabilityChecker
    private val qmpController = QmpController()
    private val vncClient = VncClient(serviceScope)
    private val audioPlayer = VmAudioPlayer()

    private var currentProfile: VmProfileEntity? = null
    private var currentQmpSocket: String = ""

    override fun onCreate() {
        super.onCreate()
        VmServiceController.activeService = this
        createNotificationChannel()
        val db = AppDatabase.getInstance(this)
        repository = VmRepository(db.vmProfileDao())
        safFileManager = SafFileManager(this)
        telemetryMonitor = TelemetryMonitor(this)
        capabilityChecker = DeviceCapabilityChecker(this)

        observeNativeEvents()
        observeVncFrames()
        startTelemetryLoop()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_VM -> {
                val vmId = intent.getLongExtra(EXTRA_VM_ID, -1L)
                if (vmId > 0L) {
                    launchVm(vmId)
                }
            }
            ACTION_TOGGLE_PAUSE -> togglePause()
            ACTION_RESET_VM -> resetVm()
            ACTION_POWERDOWN_VM -> powerdownVm()
            ACTION_FORCE_STOP_VM -> forceStopVm()
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Se o usuário deslizar o app para fechar enquanto a VM roda, tenta salvar snapshot rápido
        val status = VmServiceController.runtimeState.value.status
        if (status == VmRunStatus.RUNNING && currentQmpSocket.isNotBlank()) {
            serviceScope.launch {
                qmpController.saveState(currentQmpSocket, "auto_exit")
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        vncClient.disconnect()
        audioPlayer.stop()
        releaseWakeLock()
        telemetryJob?.cancel()
        vncObserverJob?.cancel()
        nativeCollectorJob?.cancel()
        VmServiceController.activeService = null
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun launchVm(vmId: Long) {
        serviceScope.launch(Dispatchers.IO) {
            val profile = repository.getById(vmId)
            if (profile == null) {
                VmServiceController.updateState {
                    it.copy(status = VmRunStatus.ERROR, statusMessage = "Perfil de VM não encontrado.")
                }
                stopSelf()
                return@launch
            }
            currentProfile = profile

            startForegroundCompat(buildNotification(profile.name, VmRunStatus.STARTING))
            acquireWakeLock()

            VmServiceController.updateState {
                it.copy(
                    activeVmId = profile.id,
                    activeVmName = profile.name,
                    status = VmRunStatus.STARTING,
                    statusMessage = "Preparando parâmetros e descritores de arquivo...",
                    logs = listOf("Preparando VM '${profile.name}'...")
                )
            }

            val runDir = File(filesDir, "run").apply { mkdirs() }
            val qmpPath = File(runDir, "vm_${profile.id}.qmp").apply { if (exists()) delete() }.absolutePath
            currentQmpSocket = qmpPath

            val biosDir = extractBiosAssetsIfPresent()
            val caps = capabilityChecker.inspect()

            val isoFd = profile.isoUri?.let { uri ->
                runCatching { safFileManager.openDetachedFd(uri, readWrite = false) }
                    .onFailure { VmServiceController.appendLog("ERRO ao abrir ISO via SAF: ${it.message}") }
                    .getOrNull()
            }

            val diskFd = if (!profile.liveMode && !profile.diskUri.isNullOrBlank()) {
                runCatching { safFileManager.openDetachedFd(profile.diskUri, readWrite = true) }
                    .onFailure { VmServiceController.appendLog("ERRO ao abrir disco SAF: ${it.message}") }
                    .getOrNull()
            } else {
                null
            }

            val sharedMode = runCatching { SharedStorageMode.valueOf(profile.sharedStorageMode) }
                .getOrDefault(SharedStorageMode.NONE)

            val sharedDir = if (sharedMode == SharedStorageMode.SHARED_FOLDER_VVFAT && !profile.sharedFolderUri.isNullOrBlank()) {
                runCatching { safFileManager.syncSharedTreeToLocalDir(profile.sharedFolderUri, profile.id) }
                    .onFailure { VmServiceController.appendLog("Aviso pasta compartilhada: ${it.message}") }
                    .getOrNull()?.absolutePath
            } else {
                null
            }

            val extraDiskFd = if (sharedMode == SharedStorageMode.EXTRA_DISK && !profile.extraDiskUri.isNullOrBlank()) {
                runCatching { safFileManager.openDetachedFd(profile.extraDiskUri, readWrite = true) }.getOrNull()
            } else {
                null
            }

            val spec = QemuCommandBuilder.build(
                profile = profile,
                isoFd = isoFd,
                diskFd = diskFd,
                extraDiskFd = extraDiskFd,
                sharedFatDirPath = sharedDir,
                qmpSocketPath = qmpPath,
                biosDirPath = biosDir,
                vncDisplayNumber = 1,
                kvmAvailable = caps.kvmAvailable
            )

            val cmdText = spec.toDisplayCommand()
            VmServiceController.updateState {
                it.copy(
                    vncPort = spec.vncDisplayPort,
                    qmpSocketPath = qmpPath,
                    isAudioEnabled = profile.enableAudio,
                    lastCommandLine = cmdText
                )
            }
            VmServiceController.appendLog("Comando: $cmdText")

            val arch = runCatching { VmArch.valueOf(profile.arch) }.getOrDefault(VmArch.X86_64)
            val engineAvailable = QemuNativeBridge.isEngineAvailable(arch.libraryName)
            if (!engineAvailable) {
                val msg = "Motor nativo ${arch.libraryName} não encontrado em jniLibs/arm64-v8a/. " +
                    "Compile o QEMU com os scripts em native-build/ e gere o APK com NDK."
                VmServiceController.appendLog(msg)
                VmServiceController.updateState {
                    it.copy(
                        status = VmRunStatus.ERROR,
                        statusMessage = msg,
                        nativeEngineMissing = true
                    )
                }
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return@launch
            }

            if (profile.enableAudio) {
                audioPlayer.start()
            }

            val started = QemuNativeBridge.startVm(
                libraryName = spec.libraryName,
                args = spec.args,
                ownedFds = spec.ownedFds
            )

            if (!started) {
                VmServiceController.updateState {
                    it.copy(
                        status = VmRunStatus.ERROR,
                        statusMessage = "Falha ao iniciar thread nativa do QEMU."
                    )
                }
                audioPlayer.stop()
                releaseWakeLock()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return@launch
            }

            VmServiceController.updateState {
                it.copy(
                    status = VmRunStatus.RUNNING,
                    statusMessage = "Em execução (VNC 127.0.0.1:${spec.vncDisplayPort})",
                    nativeEngineMissing = false
                )
            }
            updateNotification(profile.name, VmRunStatus.RUNNING)
            vncClient.connect(port = spec.vncDisplayPort)
        }
    }

    private fun togglePause() {
        val currentStatus = VmServiceController.runtimeState.value.status
        val name = currentProfile?.name ?: "VM"
        serviceScope.launch {
            if (currentStatus == VmRunStatus.RUNNING) {
                qmpController.pauseVm(currentQmpSocket).onSuccess {
                    VmServiceController.updateState {
                        it.copy(status = VmRunStatus.PAUSED, statusMessage = "VM pausada")
                    }
                    VmServiceController.appendLog("QMP: VM pausada.")
                    updateNotification(name, VmRunStatus.PAUSED)
                }.onFailure {
                    VmServiceController.appendLog("Erro ao pausar: ${it.message}")
                }
            } else if (currentStatus == VmRunStatus.PAUSED) {
                qmpController.resumeVm(currentQmpSocket).onSuccess {
                    VmServiceController.updateState {
                        it.copy(status = VmRunStatus.RUNNING, statusMessage = "Em execução")
                    }
                    VmServiceController.appendLog("QMP: VM retomada.")
                    updateNotification(name, VmRunStatus.RUNNING)
                }.onFailure {
                    VmServiceController.appendLog("Erro ao retomar: ${it.message}")
                }
            }
        }
    }

    private fun resetVm() {
        serviceScope.launch {
            qmpController.resetVm(currentQmpSocket)
                .onSuccess { VmServiceController.appendLog("QMP: Reinício enviado à VM.") }
                .onFailure { VmServiceController.appendLog("Erro ao reiniciar: ${it.message}") }
        }
    }

    private fun powerdownVm() {
        serviceScope.launch {
            qmpController.powerdownVm(currentQmpSocket)
                .onSuccess { VmServiceController.appendLog("QMP: Sinal ACPI de desligamento enviado.") }
                .onFailure { forceStopVm() }
        }
    }

    private fun forceStopVm() {
        serviceScope.launch {
            qmpController.quitVm(currentQmpSocket)
            delay(400)
            finishVmSession("VM encerrada pelo usuário.")
        }
    }

    fun saveVmState(tag: String) {
        serviceScope.launch {
            VmServiceController.appendLog("Salvando snapshot '$tag'...")
            qmpController.saveState(currentQmpSocket, tag)
                .onSuccess { VmServiceController.appendLog("Estado '$tag' salvo no disco .qcow2.") }
                .onFailure { VmServiceController.appendLog("Falha ao salvar estado (requer disco .qcow2): ${it.message}") }
        }
    }

    fun loadVmState(tag: String) {
        serviceScope.launch {
            VmServiceController.appendLog("Restaurando snapshot '$tag'...")
            qmpController.loadState(currentQmpSocket, tag)
                .onSuccess { VmServiceController.appendLog("Estado '$tag' restaurado.") }
                .onFailure { VmServiceController.appendLog("Falha ao restaurar estado: ${it.message}") }
        }
    }

    fun sendCtrlAltDel() {
        if (currentQmpSocket.isNotBlank()) {
            serviceScope.launch {
                qmpController.sendCtrlAltDel(currentQmpSocket)
            }
        }
        vncClient.sendCtrlAltDel()
    }

    fun sendPointer(x: Int, y: Int, buttonMask: Int) {
        vncClient.sendPointerEvent(x, y, buttonMask)
    }

    fun sendKeyEvent(down: Boolean, keySym: Int) {
        vncClient.sendKeyEvent(down, keySym)
    }

    fun sendKeyTap(keySym: Int) {
        vncClient.sendKeyTap(keySym)
    }

    private fun observeNativeEvents() {
        nativeCollectorJob = serviceScope.launch {
            launch {
                QemuNativeBridge.logs.collect { line ->
                    VmServiceController.appendLog(line)
                }
            }
            launch {
                QemuNativeBridge.exitEvents.collect { event ->
                    finishVmSession(event.message)
                }
            }
        }
    }

    private fun observeVncFrames() {
        vncObserverJob = serviceScope.launch {
            vncClient.frameState.collect { frame ->
                VmServiceController.updateVncFrame(frame)
            }
        }
    }

    private fun startTelemetryLoop() {
        telemetryJob = serviceScope.launch(Dispatchers.IO) {
            while (isActive) {
                val snap = telemetryMonitor.collect()
                VmServiceController.updateState { it.copy(telemetry = snap) }
                delay(2000L)
            }
        }
    }

    private fun finishVmSession(message: String) {
        vncClient.disconnect()
        audioPlayer.stop()
        releaseWakeLock()
        VmServiceController.appendLog(message)
        VmServiceController.updateState {
            it.copy(
                status = VmRunStatus.STOPPED,
                statusMessage = message
            )
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun extractBiosAssetsIfPresent(): String? {
        val assetFiles = runCatching { assets.list("qemu") }.getOrNull() ?: return null
        if (assetFiles.isEmpty()) return null
        val destDir = File(filesDir, "qemu_bios").apply { mkdirs() }
        for (name in assetFiles) {
            val outFile = File(destDir, name)
            if (!outFile.exists()) {
                runCatching {
                    assets.open("qemu/$name").use { input ->
                        outFile.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
        }
        return destDir.absolutePath
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DroidPC::VmWakeLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        }
        wakeLock = null
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notif_channel_desc)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun startForegroundCompat(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(vmName: String, status: VmRunStatus) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(vmName, status))
    }

    private fun buildNotification(vmName: String, status: VmRunStatus): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, VmForegroundService::class.java).apply { action = ACTION_TOGGLE_PAUSE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, VmForegroundService::class.java).apply { action = ACTION_FORCE_STOP_VM },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = when (status) {
            VmRunStatus.PAUSED -> getString(R.string.notif_paused_title, vmName)
            VmRunStatus.STARTING -> getString(R.string.notif_starting_title, vmName)
            else -> getString(R.string.notif_running_title, vmName)
        }

        val pauseLabel = if (status == VmRunStatus.PAUSED) {
            getString(R.string.action_resume)
        } else {
            getString(R.string.action_pause)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText("QEMU ativo em segundo plano (WakeLock ligado)")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_media_pause, pauseLabel, pauseIntent)
            .addAction(android.R.drawable.ic_delete, getString(R.string.action_powerdown), stopIntent)
            .build()
    }
}
