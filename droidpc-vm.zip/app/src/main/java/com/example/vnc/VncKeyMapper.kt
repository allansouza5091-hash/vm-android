package com.example.vnc

import android.view.KeyEvent

object VncKeyMapper {
    const val KEYSYM_BACKSPACE = 0xFF08
    const val KEYSYM_TAB = 0xFF09
    const val KEYSYM_RETURN = 0xFF0D
    const val KEYSYM_ESCAPE = 0xFF1B
    const val KEYSYM_HOME = 0xFF50
    const val KEYSYM_LEFT = 0xFF51
    const val KEYSYM_UP = 0xFF52
    const val KEYSYM_RIGHT = 0xFF53
    const val KEYSYM_DOWN = 0xFF54
    const val KEYSYM_PAGE_UP = 0xFF55
    const val KEYSYM_PAGE_DOWN = 0xFF56
    const val KEYSYM_END = 0xFF57
    const val KEYSYM_INSERT = 0xFF63
    const val KEYSYM_DELETE = 0xFFFF
    const val KEYSYM_F1 = 0xFFBE
    const val KEYSYM_SHIFT_L = 0xFFE1
    const val KEYSYM_CTRL_L = 0xFFE3
    const val KEYSYM_ALT_L = 0xFFE9
    const val KEYSYM_SUPER_L = 0xFFEB

    fun mapAndroidKeyEvent(event: KeyEvent): Int? {
        val unicode = event.unicodeChar
        if (unicode in 0x20..0x7E) {
            return unicode
        }
        return when (event.keyCode) {
            KeyEvent.KEYCODE_DEL -> KEYSYM_BACKSPACE
            KeyEvent.KEYCODE_FORWARD_DEL -> KEYSYM_DELETE
            KeyEvent.KEYCODE_TAB -> KEYSYM_TAB
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> KEYSYM_RETURN
            KeyEvent.KEYCODE_ESCAPE -> KEYSYM_ESCAPE
            KeyEvent.KEYCODE_MOVE_HOME -> KEYSYM_HOME
            KeyEvent.KEYCODE_MOVE_END -> KEYSYM_END
            KeyEvent.KEYCODE_DPAD_LEFT -> KEYSYM_LEFT
            KeyEvent.KEYCODE_DPAD_UP -> KEYSYM_UP
            KeyEvent.KEYCODE_DPAD_RIGHT -> KEYSYM_RIGHT
            KeyEvent.KEYCODE_DPAD_DOWN -> KEYSYM_DOWN
            KeyEvent.KEYCODE_PAGE_UP -> KEYSYM_PAGE_UP
            KeyEvent.KEYCODE_PAGE_DOWN -> KEYSYM_PAGE_DOWN
            KeyEvent.KEYCODE_INSERT -> KEYSYM_INSERT
            KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> KEYSYM_SHIFT_L
            KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> KEYSYM_CTRL_L
            KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT -> KEYSYM_ALT_L
            KeyEvent.KEYCODE_META_LEFT, KeyEvent.KEYCODE_META_RIGHT -> KEYSYM_SUPER_L
            KeyEvent.KEYCODE_SPACE -> 0x0020
            in KeyEvent.KEYCODE_F1..KeyEvent.KEYCODE_F12 ->
                KEYSYM_F1 + (event.keyCode - KeyEvent.KEYCODE_F1)
            else -> null
        }
    }
}
