package com.example.vnc

import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class VncFrameState(
    val connected: Boolean = false,
    val width: Int = 800,
    val height: Int = 600,
    val desktopName: String = "",
    val imageBitmap: ImageBitmap? = null,
    val frameCounter: Long = 0L,
    val error: String? = null
)

class VncClient(private val scope: CoroutineScope) {
    private val _frameState = MutableStateFlow(VncFrameState())
    val frameState: StateFlow<VncFrameState> = _frameState.asStateFlow()

    private var connectionJob: Job? = null
    private var socket: Socket? = null
    private var output: DataOutputStream? = null
    private val writeLock = Any()

    private var fbWidth = 800
    private var fbHeight = 600
    private var pixels = IntArray(fbWidth * fbHeight)
    private var bitmap: Bitmap = Bitmap.createBitmap(fbWidth, fbHeight, Bitmap.Config.ARGB_8888)

    fun connect(port: Int, host: String = "127.0.0.1") {
        disconnect()
        connectionJob = scope.launch(Dispatchers.IO) {
            var retries = 0
            while (isActive && retries < 25) {
                try {
                    val sock = Socket()
                    sock.connect(InetSocketAddress(host, port), 1000)
                    sock.tcpNoDelay = true
                    socket = sock

                    val input = DataInputStream(BufferedInputStream(sock.getInputStream(), 65536))
                    val out = DataOutputStream(sock.getOutputStream())
                    output = out

                    performHandshake(input, out)
                    sendPixelFormatAndEncodings(out)
                    _frameState.value = _frameState.value.copy(connected = true, error = null)

                    var incremental = false
                    while (isActive && !sock.isClosed) {
                        sendFramebufferUpdateRequest(out, incremental, 0, 0, fbWidth, fbHeight)
                        incremental = true
                        val msgType = input.readUnsignedByte()
                        when (msgType) {
                            0 -> handleFramebufferUpdate(input)
                            1 -> skipColorMapEntries(input)
                            2 -> Unit // Bell
                            3 -> skipServerCutText(input)
                            else -> break
                        }
                    }
                    break
                } catch (e: Exception) {
                    retries++
                    if (retries >= 25 || !isActive) {
                        _frameState.value = _frameState.value.copy(
                            connected = false,
                            error = e.message ?: "Conexão VNC encerrada"
                        )
                        break
                    }
                    delay(350)
                }
            }
        }
    }

    fun disconnect() {
        connectionJob?.cancel()
        connectionJob = null
        runCatching { socket?.close() }
        socket = null
        output = null
        _frameState.value = _frameState.value.copy(connected = false)
    }

    fun sendPointerEvent(x: Int, y: Int, buttonMask: Int) {
        val out = output ?: return
        val clampedX = x.coerceIn(0, (fbWidth - 1).coerceAtLeast(0))
        val clampedY = y.coerceIn(0, (fbHeight - 1).coerceAtLeast(0))
        scope.launch(Dispatchers.IO) {
            runCatching {
                synchronized(writeLock) {
                    out.writeByte(5) // PointerEvent
                    out.writeByte(buttonMask and 0xFF)
                    out.writeShort(clampedX)
                    out.writeShort(clampedY)
                    out.flush()
                }
            }
        }
    }

    fun sendKeyEvent(down: Boolean, keySym: Int) {
        val out = output ?: return
        scope.launch(Dispatchers.IO) {
            runCatching {
                synchronized(writeLock) {
                    out.writeByte(4) // KeyEvent
                    out.writeByte(if (down) 1 else 0)
                    out.writeShort(0) // padding
                    out.writeInt(keySym)
                    out.flush()
                }
            }
        }
    }

    fun sendKeyTap(keySym: Int) {
        sendKeyEvent(true, keySym)
        sendKeyEvent(false, keySym)
    }

    fun sendCtrlAltDel() {
        val out = output ?: return
        scope.launch(Dispatchers.IO) {
            runCatching {
                synchronized(writeLock) {
                    writeKeySync(out, true, VncKeyMapper.KEYSYM_CTRL_L)
                    writeKeySync(out, true, VncKeyMapper.KEYSYM_ALT_L)
                    writeKeySync(out, true, VncKeyMapper.KEYSYM_DELETE)
                    writeKeySync(out, false, VncKeyMapper.KEYSYM_DELETE)
                    writeKeySync(out, false, VncKeyMapper.KEYSYM_ALT_L)
                    writeKeySync(out, false, VncKeyMapper.KEYSYM_CTRL_L)
                    out.flush()
                }
            }
        }
    }

    private fun writeKeySync(out: DataOutputStream, down: Boolean, keySym: Int) {
        out.writeByte(4)
        out.writeByte(if (down) 1 else 0)
        out.writeShort(0)
        out.writeInt(keySym)
    }

    private fun performHandshake(input: DataInputStream, out: DataOutputStream) {
        val versionBytes = ByteArray(12)
        input.readFully(versionBytes)
        out.write("RFB 003.008\n".toByteArray(Charsets.US_ASCII))
        out.flush()

        val numSecTypes = input.readUnsignedByte()
        if (numSecTypes == 0) {
            val len = input.readInt()
            val err = ByteArray(len)
            input.readFully(err)
            throw IllegalStateException(String(err, Charsets.UTF_8))
        }
        val secTypes = ByteArray(numSecTypes)
        input.readFully(secTypes)
        if (!secTypes.contains(1.toByte())) {
            throw IllegalStateException("Servidor VNC não aceitou autenticação None.")
        }
        out.writeByte(1) // None
        out.flush()

        val secResult = input.readInt()
        if (secResult != 0) {
            throw IllegalStateException("Falha no handshake VNC: $secResult")
        }

        out.writeByte(1) // shared-flag = 1
        out.flush()

        val newWidth = input.readUnsignedShort()
        val newHeight = input.readUnsignedShort()
        input.skipBytes(16) // Server pixel format
        val nameLen = input.readInt().coerceIn(0, 4096)
        val nameBytes = ByteArray(nameLen)
        input.readFully(nameBytes)
        val name = String(nameBytes, Charsets.UTF_8)

        resizeFramebuffer(newWidth, newHeight, name)
    }

    private fun resizeFramebuffer(width: Int, height: Int, name: String = _frameState.value.desktopName) {
        val safeW = width.coerceIn(64, 3840)
        val safeH = height.coerceIn(64, 2160)
        if (safeW != fbWidth || safeH != fbHeight || pixels.size != safeW * safeH) {
            fbWidth = safeW
            fbHeight = safeH
            pixels = IntArray(safeW * safeH)
            bitmap = Bitmap.createBitmap(safeW, safeH, Bitmap.Config.ARGB_8888)
        }
        _frameState.value = _frameState.value.copy(
            width = safeW,
            height = safeH,
            desktopName = name
        )
    }

    private fun sendPixelFormatAndEncodings(out: DataOutputStream) {
        synchronized(writeLock) {
            // SetPixelFormat: 32bpp little-endian ARGB
            out.writeByte(0)
            out.writeByte(0); out.writeByte(0); out.writeByte(0)
            out.writeByte(32) // bits-per-pixel
            out.writeByte(24) // depth
            out.writeByte(0)  // big-endian-flag = 0 (little-endian)
            out.writeByte(1)  // true-color-flag = 1
            out.writeShort(255) // red-max
            out.writeShort(255) // green-max
            out.writeShort(255) // blue-max
            out.writeByte(16)   // red-shift
            out.writeByte(8)    // green-shift
            out.writeByte(0)    // blue-shift
            out.writeByte(0); out.writeByte(0); out.writeByte(0)

            // SetEncodings: Raw (0), CopyRect (1), DesktopSize (-223)
            out.writeByte(2)
            out.writeByte(0)
            out.writeShort(3)
            out.writeInt(0)
            out.writeInt(1)
            out.writeInt(-223)
            out.flush()
        }
    }

    private fun sendFramebufferUpdateRequest(
        out: DataOutputStream,
        incremental: Boolean,
        x: Int,
        y: Int,
        w: Int,
        h: Int
    ) {
        synchronized(writeLock) {
            out.writeByte(3)
            out.writeByte(if (incremental) 1 else 0)
            out.writeShort(x)
            out.writeShort(y)
            out.writeShort(w)
            out.writeShort(h)
            out.flush()
        }
    }

    private fun handleFramebufferUpdate(input: DataInputStream) {
        input.readByte() // padding
        val rectCount = input.readUnsignedShort()
        for (i in 0 until rectCount) {
            val x = input.readUnsignedShort()
            val y = input.readUnsignedShort()
            val w = input.readUnsignedShort()
            val h = input.readUnsignedShort()
            val encoding = input.readInt()

            when (encoding) {
                0 -> decodeRawRect(input, x, y, w, h)
                1 -> decodeCopyRect(input, x, y, w, h)
                -223 -> resizeFramebuffer(w, h)
                else -> throw IllegalStateException("Encoding VNC não suportado: $encoding")
            }
        }
        bitmap.setPixels(pixels, 0, fbWidth, 0, 0, fbWidth, fbHeight)
        val snapshot = bitmap.copy(Bitmap.Config.ARGB_8888, false).asImageBitmap()
        _frameState.value = _frameState.value.copy(
            imageBitmap = snapshot,
            frameCounter = _frameState.value.frameCounter + 1L
        )
    }

    private fun decodeRawRect(input: DataInputStream, rx: Int, ry: Int, rw: Int, rh: Int) {
        val rowBytes = rw * 4
        val rowBuffer = ByteArray(rowBytes)
        val bb = ByteBuffer.wrap(rowBuffer).order(ByteOrder.LITTLE_ENDIAN)
        for (row in 0 until rh) {
            input.readFully(rowBuffer)
            val destY = ry + row
            if (destY >= fbHeight) continue
            bb.rewind()
            val rowOffset = destY * fbWidth
            for (col in 0 until rw) {
                val pixel = bb.int or (0xFF shl 24)
                val destX = rx + col
                if (destX < fbWidth) {
                    pixels[rowOffset + destX] = pixel
                }
            }
        }
    }

    private fun decodeCopyRect(input: DataInputStream, dx: Int, dy: Int, w: Int, h: Int) {
        val sx = input.readUnsignedShort()
        val sy = input.readUnsignedShort()
        val copyBuf = IntArray(w * h)
        for (row in 0 until h) {
            for (col in 0 until w) {
                val srcX = (sx + col).coerceIn(0, fbWidth - 1)
                val srcY = (sy + row).coerceIn(0, fbHeight - 1)
                copyBuf[row * w + col] = pixels[srcY * fbWidth + srcX]
            }
        }
        for (row in 0 until h) {
            val destY = dy + row
            if (destY >= fbHeight) continue
            for (col in 0 until w) {
                val destX = dx + col
                if (destX < fbWidth) {
                    pixels[destY * fbWidth + destX] = copyBuf[row * w + col]
                }
            }
        }
    }

    private fun skipColorMapEntries(input: DataInputStream) {
        input.skipBytes(3)
        val count = input.readUnsignedShort()
        input.skipBytes(count * 6)
    }

    private fun skipServerCutText(input: DataInputStream) {
        input.skipBytes(3)
        val len = input.readInt()
        if (len > 0) input.skipBytes(len)
    }
}
