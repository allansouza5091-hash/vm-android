package com.example.domain

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream

data class SafFileMetadata(
    val uriString: String,
    val displayName: String,
    val sizeBytes: Long
)

class SafFileManager(private val context: Context) {

    fun persistReadPermission(uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, flags)
        }
    }

    fun persistReadWritePermission(uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, flags)
        }.onFailure {
            persistReadPermission(uri)
        }
    }

    fun queryMetadata(uri: Uri): SafFileMetadata {
        var name = uri.lastPathSegment ?: "arquivo"
        var size = 0L
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
                }
            }
        }
        return SafFileMetadata(
            uriString = uri.toString(),
            displayName = name,
            sizeBytes = size
        )
    }

    fun openDetachedFd(uriString: String, readWrite: Boolean): Int {
        val uri = Uri.parse(uriString)
        val mode = if (readWrite) "rw" else "r"
        val pfd: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, mode)
            ?: throw IllegalStateException("Não foi possível abrir o arquivo selecionado via SAF.")
        return pfd.detachFd()
    }

    /**
     * Sincroniza os arquivos de uma pasta selecionada via OpenDocumentTree para um diretório privado
     * legível por POSIX (-drive file=fat:rw:...) sem exigir permissões amplas de armazenamento.
     */
    fun syncSharedTreeToLocalDir(treeUriString: String, vmId: Long): File {
        val targetDir = File(context.filesDir, "shared/vm_$vmId").apply { mkdirs() }
        val treeUri = Uri.parse(treeUriString)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri,
            DocumentsContract.getTreeDocumentId(treeUri)
        )

        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIdx = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)

            while (cursor.moveToNext()) {
                val docId = cursor.getString(idIdx)
                val name = cursor.getString(nameIdx) ?: continue
                val mime = cursor.getString(mimeIdx)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) continue

                val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                val outFile = File(targetDir, name.replace(Regex("[^a-zA-Z0-9._-]"), "_"))
                context.contentResolver.openInputStream(docUri)?.use { input ->
                    FileOutputStream(outFile).use { output ->
                        input.copyTo(output)
                    }
                }
            }
        }
        return targetDir
    }
}
