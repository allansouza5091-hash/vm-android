package com.example.domain

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import com.example.data.model.DeviceCapabilities
import com.example.data.model.VmArch
import com.example.nativebridge.QemuNativeBridge
import java.io.File

class DeviceCapabilityChecker(private val context: Context) {

    fun inspect(): DeviceCapabilities {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalMb = memInfo.totalMem / (1024L * 1024L)
        val availMb = memInfo.availMem / (1024L * 1024L)
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "desconhecida"

        val kvmFile = File("/dev/kvm")
        val kvmAvailable = kvmFile.exists() && kvmFile.canRead() && kvmFile.canWrite()

        val x86Bundled = QemuNativeBridge.isEngineAvailable(VmArch.X86_64.libraryName)
        val arm64Bundled = QemuNativeBridge.isEngineAvailable(VmArch.AARCH64.libraryName)

        return DeviceCapabilities(
            totalRamMb = totalMb,
            availableRamMb = availMb,
            cpuCores = cores,
            primaryAbi = abi,
            kvmAvailable = kvmAvailable,
            x86EngineBundled = x86Bundled,
            aarch64EngineBundled = arm64Bundled
        )
    }

    fun recommendedMaxVmRamMb(availMb: Long, totalMb: Long): Int {
        // Reserva margem segura para evitar que o LMK do Android mate a VM
        val ceiling = minOf((totalMb * 0.55).toLong(), (availMb * 0.75).toLong())
        return ceiling.coerceIn(512L, 6144L).toInt()
    }
}
