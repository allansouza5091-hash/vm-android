package com.example.domain

import com.example.data.local.VmProfileEntity
import com.example.data.model.BootOrder
import com.example.data.model.DiskFormat
import com.example.data.model.NetworkMode
import com.example.data.model.SharedStorageMode
import com.example.data.model.VideoDriver
import com.example.data.model.VmArch

data class QemuLaunchSpec(
    val libraryName: String,
    val args: List<String>,
    val ownedFds: IntArray,
    val vncDisplayPort: Int,
    val qmpSocketPath: String
) {
    fun toDisplayCommand(): String = args.joinToString(" ")
}

object QemuCommandBuilder {

    fun build(
        profile: VmProfileEntity,
        isoFd: Int?,
        diskFd: Int?,
        extraDiskFd: Int?,
        sharedFatDirPath: String?,
        qmpSocketPath: String,
        biosDirPath: String?,
        vncDisplayNumber: Int = 1,
        kvmAvailable: Boolean = false
    ): QemuLaunchSpec {
        val arch = runCatching { VmArch.valueOf(profile.arch) }.getOrDefault(VmArch.X86_64)
        val bootOrder = runCatching { BootOrder.valueOf(profile.bootOrder) }.getOrDefault(BootOrder.CD_THEN_DISK)
        val video = runCatching { VideoDriver.valueOf(profile.videoDriver) }.getOrDefault(VideoDriver.STD)
        val network = runCatching { NetworkMode.valueOf(profile.networkMode) }.getOrDefault(NetworkMode.USER_VIRTIO)
        val diskFormat = runCatching { DiskFormat.valueOf(profile.diskFormat) }.getOrDefault(DiskFormat.QCOW2)
        val sharedMode = runCatching { SharedStorageMode.valueOf(profile.sharedStorageMode) }.getOrDefault(SharedStorageMode.NONE)

        val args = mutableListOf<String>()
        val ownedFds = mutableListOf<Int>()

        args += arch.libraryName
        args += listOf("-name", profile.name.ifBlank { "DroidPC" })

        if (!biosDirPath.isNullOrBlank()) {
            args += listOf("-L", biosDirPath)
        }

        val useKvm = arch == VmArch.AARCH64 && profile.useKvmIfAvailable && kvmAvailable
        if (useKvm) {
            args += listOf("-machine", "${arch.qemuMachine},accel=kvm")
            args += listOf("-cpu", "host")
        } else {
            args += listOf("-machine", arch.qemuMachine)
            args += listOf("-accel", "tcg,thread=multi,tb-size=128")
            args += listOf("-cpu", arch.defaultCpu)
        }

        args += listOf("-smp", profile.cpuCores.coerceIn(1, 8).toString())
        args += listOf("-m", "${profile.ramMb.coerceIn(256, 8192)}M")

        // Ordem de boot
        args += listOf("-boot", "order=${bootOrder.qemuOrder},menu=on")

        // ISO via File Descriptor (/proc/self/fd/<fd>)
        if (isoFd != null && isoFd >= 0) {
            ownedFds += isoFd
            args += listOf("-cdrom", "/proc/self/fd/$isoFd")
        }

        // Disco virtual principal (ou modo Live sem disco)
        if (!profile.liveMode) {
            if (diskFd != null && diskFd >= 0) {
                ownedFds += diskFd
                args += listOf(
                    "-drive",
                    "file=/proc/self/fd/$diskFd,format=${diskFormat.qemuFormat},if=virtio,cache=writeback"
                )
            } else if (!profile.diskPath.isNullOrBlank()) {
                args += listOf(
                    "-drive",
                    "file=${profile.diskPath},format=${diskFormat.qemuFormat},if=virtio,cache=writeback"
                )
            }
        }

        // Pasta compartilhada (FAT virtual) ou disco secundário
        when (sharedMode) {
            SharedStorageMode.SHARED_FOLDER_VVFAT -> {
                if (!sharedFatDirPath.isNullOrBlank()) {
                    args += listOf("-drive", "file=fat:rw:$sharedFatDirPath,format=raw,if=virtio")
                }
            }
            SharedStorageMode.EXTRA_DISK -> {
                if (extraDiskFd != null && extraDiskFd >= 0) {
                    ownedFds += extraDiskFd
                    args += listOf("-drive", "file=/proc/self/fd/$extraDiskFd,if=virtio")
                } else if (!profile.extraDiskPath.isNullOrBlank()) {
                    args += listOf("-drive", "file=${profile.extraDiskPath},if=virtio")
                }
            }
            SharedStorageMode.NONE -> Unit
        }

        // Vídeo
        args += listOf("-vga", video.qemuFlagValue)

        // Ponteiro absoluto USB Tablet (fundamental para toque = clique sem desalinhamento)
        args += listOf("-usb", "-device", "usb-tablet")

        // Rede NAT / User-Mode (SLIRP)
        when (network) {
            NetworkMode.USER_VIRTIO -> {
                args += listOf("-netdev", "user,id=net0")
                args += listOf("-device", "virtio-net-pci,netdev=net0")
            }
            NetworkMode.USER_E1000 -> {
                args += listOf("-netdev", "user,id=net0")
                args += listOf("-device", "e1000,netdev=net0")
            }
            NetworkMode.DISABLED -> {
                args += listOf("-nic", "none")
            }
        }

        // Áudio (dispositivo AC97 ou Intel HDA; driver de saída configurado na compilação/bridge)
        if (profile.enableAudio) {
            args += listOf("-audiodev", "none,id=snd0")
            args += listOf("-device", "AC97,audiodev=snd0")
        }

        // Kernel direto (opcional, quando o usuário fornece vmlinuz + initrd extraídos)
        if (!profile.kernelPath.isNullOrBlank()) {
            args += listOf("-kernel", profile.kernelPath)
            if (!profile.initrdPath.isNullOrBlank()) {
                args += listOf("-initrd", profile.initrdPath)
            }
            if (profile.kernelOptions.isNotBlank()) {
                args += listOf("-append", profile.kernelOptions.trim())
            }
        }

        // VNC loopback local + QMP Unix Socket
        args += listOf("-vnc", "127.0.0.1:$vncDisplayNumber")
        args += listOf("-qmp", "unix:$qmpSocketPath,server=on,wait=off")
        args += listOf("-monitor", "none")

        // Argumentos extras livres
        if (profile.extraQemuArgs.isNotBlank()) {
            args += splitShellArgs(profile.extraQemuArgs)
        }

        return QemuLaunchSpec(
            libraryName = arch.libraryName,
            args = args,
            ownedFds = ownedFds.toIntArray(),
            vncDisplayPort = 5900 + vncDisplayNumber,
            qmpSocketPath = qmpSocketPath
        )
    }

    private fun splitShellArgs(raw: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        for (ch in raw.trim()) {
            when {
                ch == '"' -> inQuotes = !inQuotes
                ch.isWhitespace() && !inQuotes -> {
                    if (current.isNotEmpty()) {
                        result += current.toString()
                        current.clear()
                    }
                }
                else -> current.append(ch)
            }
        }
        if (current.isNotEmpty()) {
            result += current.toString()
        }
        return result
    }
}
