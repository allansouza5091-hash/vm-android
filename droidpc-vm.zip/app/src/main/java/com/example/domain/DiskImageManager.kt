package com.example.domain

import android.content.Context
import android.os.StatFs
import com.example.data.model.DiskFormat
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ceil

data class CreatedDiskResult(
    val file: File,
    val format: DiskFormat,
    val sizeGb: Int
)

class DiskImageManager(private val context: Context) {

    fun getDisksDirectory(): File {
        return File(context.filesDir, "disks").apply { mkdirs() }
    }

    fun listPrivateDisks(): List<File> {
        return getDisksDirectory()
            .listFiles { file ->
                file.isFile && (file.extension.equals("qcow2", true) || file.extension.equals("img", true))
            }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()
    }

    fun getAvailableStorageGb(): Double {
        val stat = StatFs(getDisksDirectory().absolutePath)
        val availBytes = stat.availableBlocksLong * stat.blockSizeLong
        return availBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
    }

    fun createDisk(nameInput: String, sizeGb: Int, format: DiskFormat): CreatedDiskResult {
        val safeName = nameInput.trim()
            .replace(Regex("[^a-zA-Z0-9._-]"), "_")
            .ifBlank { "disk_${System.currentTimeMillis()}" }
            .removeSuffix(".qcow2")
            .removeSuffix(".img")

        val file = File(getDisksDirectory(), "$safeName.${format.extension}")
        if (file.exists()) {
            throw IllegalStateException("Já existe um disco com o nome ${file.name}")
        }

        val virtualSizeBytes = sizeGb.coerceIn(1, 128).toLong() * 1024L * 1024L * 1024L
        when (format) {
            DiskFormat.RAW -> createSparseRawDisk(file, virtualSizeBytes)
            DiskFormat.QCOW2 -> createEmptyQcow2V3(file, virtualSizeBytes)
        }
        return CreatedDiskResult(file = file, format = format, sizeGb = sizeGb)
    }

    fun deleteDisk(file: File): Boolean {
        return file.exists() && file.delete()
    }

    private fun createSparseRawDisk(target: File, virtualSizeBytes: Long) {
        RandomAccessFile(target, "rw").use { raf ->
            raf.setLength(virtualSizeBytes)
        }
    }

    /**
     * Gera um arquivo QCOW2 v3 válido e vazio (cluster_bits = 16 -> clusters de 64 KiB)
     * pronto para ser aberto diretamente pelo QEMU com suporte a alocação dinâmica e savevm.
     */
    private fun createEmptyQcow2V3(target: File, virtualSizeBytes: Long) {
        val clusterBits = 16
        val clusterSize = 1 shl clusterBits // 65536 bytes
        val l2EntriesPerCluster = clusterSize / 8 // 8192
        val bytesPerL2Table = l2EntriesPerCluster.toLong() * clusterSize.toLong() // 512 MiB
        val l1Size = ceil(virtualSizeBytes.toDouble() / bytesPerL2Table.toDouble()).toInt().coerceAtLeast(1)
        val l1Bytes = l1Size * 8
        val l1Clusters = ceil(l1Bytes.toDouble() / clusterSize.toDouble()).toInt().coerceAtLeast(1)

        val refcountTableOffset = 1L * clusterSize
        val refcountBlockOffset = 2L * clusterSize
        val l1TableOffset = 3L * clusterSize
        val totalAllocatedClusters = 3 + l1Clusters

        val header = ByteBuffer.allocate(104).order(ByteOrder.BIG_ENDIAN).apply {
            putInt(0x514649fb) // Magic "QFI\xfb"
            putInt(3) // Version 3
            putLong(0L) // backing_file_offset
            putInt(0) // backing_file_size
            putInt(clusterBits) // cluster_bits (64 KiB)
            putLong(virtualSizeBytes) // size
            putInt(0) // crypt_method (none)
            putInt(l1Size) // l1_size
            putLong(l1TableOffset) // l1_table_offset
            putLong(refcountTableOffset) // refcount_table_offset
            putInt(1) // refcount_table_clusters
            putInt(0) // nb_snapshots
            putLong(0L) // snapshots_offset
            putLong(0L) // incompatible_features
            putLong(0L) // compatible_features
            putLong(0L) // autoclear_features
            putInt(4) // refcount_order (2^4 = 16 bits por entrada)
            putInt(104) // header_length
        }

        val refcountTableCluster = ByteArray(clusterSize)
        ByteBuffer.wrap(refcountTableCluster).order(ByteOrder.BIG_ENDIAN).putLong(0, refcountBlockOffset)

        val refcountBlockCluster = ByteArray(clusterSize)
        val refBlockBuf = ByteBuffer.wrap(refcountBlockCluster).order(ByteOrder.BIG_ENDIAN)
        for (clusterIdx in 0 until totalAllocatedClusters) {
            refBlockBuf.putShort(clusterIdx * 2, 1.toShort())
        }

        RandomAccessFile(target, "rw").use { raf ->
            raf.setLength(totalAllocatedClusters.toLong() * clusterSize)
            raf.seek(0L)
            raf.write(header.array())
            raf.seek(refcountTableOffset)
            raf.write(refcountTableCluster)
            raf.seek(refcountBlockOffset)
            raf.write(refcountBlockCluster)
        }
    }
}
