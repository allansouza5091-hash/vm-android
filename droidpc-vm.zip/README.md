# DroidPC VM — Máquina Virtual QEMU para Android

Aplicativo Android nativo em **Kotlin + Jetpack Compose + C++/JNI** para executar imagens ISO de **Android-x86, BlissOS e PrimeOS** diretamente no celular utilizando o **QEMU** empacotado via NDK (`arm64-v8a`).

## Arquitetura
- **UI (Jetpack Compose):** Lista de perfis, criação/edição de VM, seletor de ISO via Storage Access Framework (SAF), criador de discos `.qcow2` v3 / `.img`, visor VNC com captura de toque/teclado/mouse Bluetooth/USB e painel de logs.
- **Serviço e Domínio:** `VmForegroundService` (`foregroundServiceType="specialUse"`) com `WakeLock`, notificação persistente (Pausar/Retomar/Desligar), cliente RFB 3.8 (`VncClient`), controlador QMP (`QmpController`), reprodutor de áudio (`VmAudioPlayer`) e monitor de telemetria (`TelemetryMonitor`).
- **Camada Nativa (C++/JNI):** `libqemu_bridge.so` carrega `libqemu-system-x86_64.so` / `libqemu-system-aarch64.so` via `dlopen`, executa `qemu_main` em thread dedicada, redireciona `stdout`/`stderr` e repassa descritores de arquivo (`/proc/self/fd/<fd>`).

## Compilar o motor QEMU com Android NDK (`arm64-v8a`)
O APK compilado apenas pelo Gradle Java/Kotlin inclui toda a interface, banco Room, VNC, gerador de `.qcow2` e ponte JNI. Para habilitar a execução do QEMU no aparelho físico, compile o motor nativo em um ambiente Linux x86_64 usando os scripts incluídos em `native-build/`:

```bash
export ANDROID_NDK_HOME="$HOME/android-sdk/android-ndk-r26d"
chmod +x native-build/*.sh native-build/*.py
./native-build/build_deps.sh
./native-build/build_qemu.sh
```

Os arquivos `libqemu-system-x86_64.so` e `libqemu-system-aarch64.so` serão copiados para `app/src/main/jniLibs/arm64-v8a/`. Em seguida, compile o APK com NDK/CMake instalado (`gradle assembleDebug` ou Android Studio).

## Testes e Depuração
- **Testes unitários e Robolectric:**
  ```bash
  gradle :app:testDebugUnitTest
  ```
- **Tela preta no boot:** No menu GRUB da ISO, pressione `e` e adicione `nomodeset`. Teste também alternar o driver de vídeo entre `std` e `virtio` nas configurações da VM.
- **Falta de memória (OOM):** Reduza a RAM da VM para 1024–1536 MB (mantendo margem livre para o Android).
- **ISO não reconhecida:** Confira nos logs se o FD foi aberto via SAF e se a ordem de boot está como `CD-ROM (ISO) -> Disco`.
- **Logcat:**
  ```bash
  adb logcat -s DroidPC_JNI DroidPC_Audio VmForegroundService
  ```

## Limitações conhecidas
- A emulação x86 em ARM via TCG não usa aceleração de GPU do celular (boot e interface do guest serão lentos).
- Sensores, câmera e GPS do telefone não são repassados para a VM.
- KVM só funciona em aparelhos ARM64 com `/dev/kvm` acessível no kernel.

## Licença
Distribuído sob **GNU GPL v2+** em conformidade com o uso do QEMU. Consulte `LICENSE`.
