#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/env_arm64.sh"

JOBS="$(nproc)"
MESON_CROSS="$ROOT_BUILD_DIR/generated_meson_arm64.txt"

sed -e "s|@TOOLCHAIN@|$TOOLCHAIN|g" \
    -e "s|@PREFIX@|$PREFIX|g" \
    "$ROOT_BUILD_DIR/meson_android_arm64.txt" > "$MESON_CROSS"

download_and_extract() {
  local url="$1"
  local archive="$2"
  local folder="$3"
  cd "$SRC_DIR"
  if [ ! -f "$archive" ]; then
    echo ">>> Baixando $archive..."
    curl -L --fail -o "$archive" "$url"
  fi
  if [ ! -d "$folder" ]; then
    echo ">>> Extraindo $archive..."
    tar xf "$archive"
  fi
}

download_and_extract \
  "https://github.com/madler/zlib/releases/download/v1.3.1/zlib-1.3.1.tar.xz" \
  "zlib-1.3.1.tar.xz" \
  "zlib-1.3.1"
cd "$SRC_DIR/zlib-1.3.1"
make distclean >/dev/null 2>&1 || true
CHOST="$TARGET_TRIPLE" ./configure --prefix="$PREFIX" --static
make -j"$JOBS"
make install

download_and_extract \
  "https://github.com/libffi/libffi/releases/download/v3.4.6/libffi-3.4.6.tar.gz" \
  "libffi-3.4.6.tar.gz" \
  "libffi-3.4.6"
cd "$SRC_DIR/libffi-3.4.6"
rm -rf build-arm64 && mkdir build-arm64 && cd build-arm64
../configure \
  --host="$TARGET_TRIPLE" \
  --prefix="$PREFIX" \
  --enable-static \
  --disable-shared \
  --disable-docs \
  --with-pic
make -j"$JOBS"
make install

download_and_extract \
  "https://github.com/PCRE2Project/pcre2/releases/download/pcre2-10.43/pcre2-10.43.tar.bz2" \
  "pcre2-10.43.tar.bz2" \
  "pcre2-10.43"
cd "$SRC_DIR/pcre2-10.43"
rm -rf build-arm64 && mkdir build-arm64 && cd build-arm64
../configure \
  --host="$TARGET_TRIPLE" \
  --prefix="$PREFIX" \
  --enable-static \
  --disable-shared \
  --enable-pcre2-8 \
  --disable-pcre2grep-jit \
  --with-pic
make -j"$JOBS"
make install

download_and_extract \
  "https://github.com/frida/proxy-libintl/archive/refs/tags/0.4.tar.gz" \
  "proxy-libintl-0.4.tar.gz" \
  "proxy-libintl-0.4"
cd "$SRC_DIR/proxy-libintl-0.4"
rm -rf build-arm64
meson setup build-arm64 \
  --cross-file "$MESON_CROSS" \
  --prefix="$PREFIX" \
  --default-library=static \
  -Dbuildtype=release
ninja -C build-arm64 -j"$JOBS"
ninja -C build-arm64 install

download_and_extract \
  "https://download.gnome.org/sources/glib/2.80/glib-2.80.2.tar.xz" \
  "glib-2.80.2.tar.xz" \
  "glib-2.80.2"
cd "$SRC_DIR/glib-2.80.2"
rm -rf build-arm64
meson setup build-arm64 \
  --cross-file "$MESON_CROSS" \
  --prefix="$PREFIX" \
  --default-library=static \
  -Dbuildtype=release \
  -Dtests=false \
  -Dintrospection=disabled \
  -Ddocumentation=false \
  -Dman-pages=disabled \
  -Dselinux=disabled \
  -Dxattr=false \
  -Dlibmount=disabled \
  -Dlibelf=disabled \
  -Dnls=disabled
ninja -C build-arm64 -j"$JOBS"
ninja -C build-arm64 install

download_and_extract \
  "https://www.cairographics.org/releases/pixman-0.43.4.tar.gz" \
  "pixman-0.43.4.tar.gz" \
  "pixman-0.43.4"
cd "$SRC_DIR/pixman-0.43.4"
rm -rf build-arm64
meson setup build-arm64 \
  --cross-file "$MESON_CROSS" \
  --prefix="$PREFIX" \
  --default-library=static \
  -Dbuildtype=release \
  -Dtests=disabled \
  -Ddemos=disabled \
  -Dgtk=disabled \
  -Da64-neon=enabled \
  -Dopenmp=disabled
ninja -C build-arm64 -j"$JOBS"
ninja -C build-arm64 install

download_and_extract \
  "https://gitlab.freedesktop.org/slirp/libslirp/-/archive/v4.8.0/libslirp-v4.8.0.tar.gz" \
  "libslirp-v4.8.0.tar.gz" \
  "libslirp-v4.8.0"
cd "$SRC_DIR/libslirp-v4.8.0"
rm -rf build-arm64
meson setup build-arm64 \
  --cross-file "$MESON_CROSS" \
  --prefix="$PREFIX" \
  --default-library=static \
  -Dbuildtype=release
ninja -C build-arm64 -j"$JOBS"
ninja -C build-arm64 install
