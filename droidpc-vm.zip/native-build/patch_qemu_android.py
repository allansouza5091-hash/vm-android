#!/usr/bin/env python3
import pathlib
import sys

def patch_system_main(qemu_dir: pathlib.Path) -> None:
    main_c = qemu_dir / "system" / "main.c"
    content = main_c.read_text(encoding="utf-8")
    if "qemu_main(" in content:
        return

    old_sig = "int main(int argc, char **argv)"
    if old_sig not in content:
        raise RuntimeError("Assinatura esperada de main() não encontrada em system/main.c")

    replacement = (
        "__attribute__((visibility(\"default\")))\n"
        "int qemu_main(int argc, char **argv)"
    )
    content = content.replace(old_sig, replacement, 1)
    main_c.write_text(content, encoding="utf-8")

def patch_meson_build(qemu_dir: pathlib.Path) -> None:
    meson_file = qemu_dir / "meson.build"
    content = meson_file.read_text(encoding="utf-8")
    marker = "# ANDROID_SHARED_LIB_PATCH"
    if marker in content:
        return

    old_exec = (
        "    emulator = executable(exe_name, exe['sources'],\n"
        "               install: true,\n"
        "               c_args: c_args,\n"
        "               dependencies: exe['dependencies'],\n"
        "               objects: exe['objects'],\n"
        "               link_args: link_args)\n"
    )
    new_exec = (
        f"    {marker}\n"
        "    if exe_name.startswith('qemu-system-')\n"
        "      emulator = shared_library(exe_name, exe['sources'],\n"
        "                 name_prefix: 'lib',\n"
        "                 install: true,\n"
        "                 c_args: c_args,\n"
        "                 dependencies: exe['dependencies'],\n"
        "                 objects: exe['objects'],\n"
        "                 link_args: link_args + ['-Wl,-soname,lib' + exe_name + '.so'])\n"
        "    else\n"
        "      emulator = executable(exe_name, exe['sources'],\n"
        "                 install: true,\n"
        "                 c_args: c_args,\n"
        "                 dependencies: exe['dependencies'],\n"
        "                 objects: exe['objects'],\n"
        "                 link_args: link_args)\n"
        "    endif\n"
    )

    if old_exec not in content:
        raise RuntimeError("Bloco emulator = executable(...) não encontrado em meson.build")

    content = content.replace(old_exec, new_exec, 1)
    meson_file.write_text(content, encoding="utf-8")

def patch_oslib_posix(qemu_dir: pathlib.Path) -> None:
    oslib = qemu_dir / "util" / "oslib-posix.c"
    content = oslib.read_text(encoding="utf-8")
    if "ANDROID_GETDTABLESIZE_FIX" in content:
        return
    if "getdtablesize()" in content:
        fix_header = (
            "#ifdef __ANDROID__\n"
            "/* ANDROID_GETDTABLESIZE_FIX */\n"
            "#define getdtablesize() ((int)sysconf(_SC_OPEN_MAX))\n"
            "#endif\n"
        )
        oslib.write_text(fix_header + content, encoding="utf-8")

def main() -> None:
    if len(sys.argv) != 2:
        print(f"Uso: {sys.argv[0]} <caminho_para_qemu_source>")
        sys.exit(1)
    qemu_dir = pathlib.Path(sys.argv[1]).resolve()
    patch_system_main(qemu_dir)
    patch_meson_build(qemu_dir)
    patch_oslib_posix(qemu_dir)

if __name__ == "__main__":
    main()
