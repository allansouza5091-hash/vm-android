#!/usr/bin/env bash
set -euo pipefail

if [ -z "${ANDROID_NDK_HOME:-}" ]; then
  echo "ERRO: Defina ANDROID_NDK_HOME antes de carregar env_arm64.sh"
  exit 1
fi

export ROOT_BUILD_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export SRC_DIR="$ROOT_BUILD_DIR/sources"
export PREFIX="$ROOT_BUILD_DIR/sysroot-arm64"
export ANDROID_API=26
export TARGET_TRIPLE="aarch64-linux-android"
export TOOLCHAIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64"

export PATH="$TOOLCHAIN/bin:$HOME/.local/bin:$PATH"

export CC="$TOOLCHAIN/bin/${TARGET_TRIPLE}${ANDROID_API}-clang"
export CXX="$TOOLCHAIN/bin/${TARGET_TRIPLE}${ANDROID_API}-clang++"
export AR="$TOOLCHAIN/bin/llvm-ar"
export AS="$TOOLCHAIN/bin/llvm-as"
export LD="$TOOLCHAIN/bin/ld.lld"
export RANLIB="$TOOLCHAIN/bin/llvm-ranlib"
export NM="$TOOLCHAIN/bin/llvm-nm"
export STRIP="$TOOLCHAIN/bin/llvm-strip"
export PKG_CONFIG="pkg-config"

export PKG_CONFIG_PATH=""
export PKG_CONFIG_LIBDIR="$PREFIX/lib/pkgconfig:$PREFIX/share/pkgconfig"

export COMMON_FLAGS="-fPIC -O2 -D__ANDROID_API__=${ANDROID_API} -I$PREFIX/include"
export CFLAGS="$COMMON_FLAGS"
export CXXFLAGS="$COMMON_FLAGS"
export LDFLAGS="-L$PREFIX/lib -Wl,--build-id=sha1"

mkdir -p "$SRC_DIR" "$PREFIX/lib/pkgconfig" "$PREFIX/include"
