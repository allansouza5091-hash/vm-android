#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/env_arm64.sh"

QEMU_VER="8.2.7"
QEMU_ARCHIVE="qemu-${QEMU_VER}.tar.xz"
QEMU_SRC="$SRC_DIR/qemu-${QEMU_VER}"
QEMU_BUILD="$ROOT_BUILD_DIR/build-qemu-arm64"
JNILIBS_DIR="$(cd "$SCRIPT_DIR/.." && pwd)/app/src/main/jniLibs/arm64-v8a"
JOBS="$(nproc)"

cd "$SRC_DIR"
if [ ! -f "$QEMU_ARCHIVE" ]; then
  curl -L --fail -o "$QEMU_ARCHIVE" "https://download.qemu.org/${QEMU_ARCHIVE}"
fi

if [ ! -d "$QEMU_SRC" ]; then
  tar xf "$QEMU_ARCHIVE"
fi

python3 "$SCRIPT_DIR/patch_qemu_android.py" "$QEMU_SRC"

rm -rf "$QEMU_BUILD"
mkdir -p "$QEMU_BUILD"
cd "$QEMU_BUILD"

EXTRA_CFLAGS="-fPIC -O2 -D__ANDROID_API__=${ANDROID_API} -I${PREFIX}/include -Wno-error"
EXTRA_LDFLAGS="-L${PREFIX}/lib -Wl,--export-dynamic -Wl,--allow-multiple-definition -llog"

"$QEMU_SRC/configure" \
  --cross-prefix="${TARGET_TRIPLE}${ANDROID_API}-" \
  --cc="$CC" \
  --cxx="$CXX" \
  --ar="$AR" \
  --ranlib="$RANLIB" \
  --nm="$NM" \
  --strip="$STRIP" \
  --target-list="x86_64-softmmu,aarch64-softmmu" \
  --enable-tcg \
  --enable-kvm \
  --enable-slirp \
  --enable-vnc \
  --disable-vnc-jpeg \
  --disable-vnc-sasl \
  --disable-gtk \
  --disable-sdl \
  --disable-curses \
  --disable-cocoa \
  --disable-opengl \
  --disable-virglrenderer \
  --disable-spice \
  --disable-spice-protocol \
  --disable-capstone \
  --disable-docs \
  --disable-tests \
  --disable-tools \
  --disable-werror \
  --disable-pie \
  --disable-libusb \
  --disable-usb-redir \
  --disable-smartcard \
  --disable-brlapi \
  --disable-curl \
  --disable-libssh \
  --disable-libnfs \
  --disable-glusterfs \
  --disable-rbd \
  --disable-vde \
  --disable-nettle \
  --disable-gcrypt \
  --disable-gnutls \
  --disable-zstd \
  --disable-lzo \
  --disable-snappy \
  --disable-bzip2 \
  --disable-rdma \
  --disable-tpm \
  --disable-vhost-user \
  --disable-vhost-vdpa \
  --disable-vhost-net \
  --disable-vhost-crypto \
  --disable-dbus-display \
  --disable-gio \
  --disable-linux-io-uring \
  --disable-libudev \
  --disable-attr \
  --disable-cap-ng \
  --disable-seccomp \
  --disable-selinux \
  --disable-plugins \
  --audio-drv-list="" \
  --extra-cflags="$EXTRA_CFLAGS" \
  --extra-ldflags="$EXTRA_LDFLAGS"

ninja -j"$JOBS" qemu-system-x86_64 qemu-system-aarch64

mkdir -p "$JNILIBS_DIR"
cp -f "$QEMU_BUILD/libqemu-system-x86_64.so" "$JNILIBS_DIR/libqemu-system-x86_64.so"
cp -f "$QEMU_BUILD/libqemu-system-aarch64.so" "$JNILIBS_DIR/libqemu-system-aarch64.so"

"$STRIP" --strip-unneeded "$JNILIBS_DIR/libqemu-system-x86_64.so"
"$STRIP" --strip-unneeded "$JNILIBS_DIR/libqemu-system-aarch64.so"
